import { relative } from "node:path";
import { defaultMaxMoves, defaultTimeoutMs, type CheckReport, type CountSummary } from "./check";
import type { Finding } from "./findings";

export function formatReport(report: CheckReport, cwd: string = process.cwd()): string {
  const where = (relative(cwd, report.gameDir) || ".").replaceAll("\\", "/");
  const command = replayCommand(where, report.settings);
  const lines: string[] = [];
  lines.push(`Prüfe ${report.manifest?.name ?? where} (${where})`, "");

  if (report.manifest !== undefined) {
    lines.push("Manifest: in Ordnung");
  }
  for (const note of report.notes) {
    lines.push(`Hinweis: ${note}`);
  }

  if (report.summaries.length > 0) {
    lines.push("", "Bot-Partien:");
    for (const summary of report.summaries) {
      lines.push(`  ${formatSummary(summary)}`);
    }
  }

  if (report.replay !== undefined) {
    const run = report.replay;
    lines.push("", `Partie mit Seed ${run.seed} und ${run.playerCount} Spielern:`);
    run.moves.forEach((move, index) => {
      lines.push(`  Zug ${index + 1}: ${move.player} ${JSON.stringify(move.action)}`);
    });
    lines.push(`  Ende: ${run.result === undefined ? "ohne Ergebnis" : `Gewinner ${run.result.winners.join(", ") || "keiner"}`}`);
  }

  const errors = report.findings.filter((finding) => finding.severity === "error");
  const warnings = report.findings.filter((finding) => finding.severity === "warning");
  for (const finding of report.findings) {
    lines.push("", ...formatFinding(finding, command));
  }
  lines.push("", `Ergebnis: ${count(errors.length, "Fehler", "Fehler")}, ${count(warnings.length, "Warnung", "Warnungen")}`);
  return lines.join("\n");
}

function formatSummary(summary: CountSummary): string {
  const parts = [`${summary.playerCount} Spieler: ${summary.games} Partien`];
  if (summary.finished === summary.games) {
    parts.push("alle beendet");
  } else {
    parts.push(`${summary.finished} beendet, ${summary.tooLong} zu lang, ${summary.failed} mit Fehler`);
  }
  parts.push(`im Schnitt ${summary.averageMoves} Züge (längste ${summary.longest})`);
  if (summary.finished > 0) {
    const shares = Object.entries(summary.wins)
      .sort(([a], [b]) => a.localeCompare(b, "de", { numeric: true }))
      .map(([seat, wins]) => `${seat} ${Math.round((wins / summary.finished) * 100)} %`);
    if (shares.length > 0) {
      parts.push(`Siege: ${shares.join(", ")}`);
    }
    if (summary.withoutWinner > 0) {
      parts.push(`ohne Gewinner: ${summary.withoutWinner}`);
    }
  }
  return parts.join(", ");
}

function replayCommand(where: string, settings: CheckReport["settings"]): (playerCount: number, seed: string) => string {
  const path = /^[\w./:-]+$/.test(where) ? where : `"${where}"`;
  const extra = [
    settings.maxMoves === defaultMaxMoves ? "" : ` --max-moves ${settings.maxMoves}`,
    settings.timeoutMs === defaultTimeoutMs ? "" : ` --timeout ${settings.timeoutMs}`,
  ].join("");
  return (playerCount, seed) => `npm run gamehearth -- check ${path} --players ${playerCount} --seed ${seed}${extra}`;
}

function formatFinding(finding: Finding, command: (playerCount: number, seed: string) => string): string[] {
  const label = finding.severity === "error" ? "FEHLER " : "WARNUNG";
  const lines = [`${label}  ${finding.message}`];
  if (finding.detail !== undefined) {
    lines.push(`         ${finding.detail}`);
  }
  const context: string[] = [];
  if (finding.playerCount !== undefined) context.push(`${finding.playerCount} Spieler`);
  if (finding.seed !== undefined) context.push(`Seed ${finding.seed}`);
  if (finding.step !== undefined) context.push(finding.step === 0 ? "beim Start" : `Zug ${finding.step}`);
  if (finding.phase !== undefined) context.push(`in ${finding.phase}`);
  if (finding.player !== undefined) context.push(`Sitz ${finding.player}`);
  if ((finding.count ?? 1) > 1) context.push(`insgesamt ${finding.count}-mal`);
  if (context.length > 0) {
    lines.push(`         ${context.join(", ")}`);
  }
  if (finding.seed !== undefined && finding.playerCount !== undefined) {
    lines.push(`         Nachspielen: ${command(finding.playerCount, finding.seed)}`);
  }
  if (finding.stack !== undefined) {
    lines.push(...finding.stack.split("\n").map((line) => `         ${line.trim()}`));
  }
  return lines;
}

function count(value: number, singular: string, plural: string): string {
  return `${value === 0 ? "keine" : value} ${value === 1 ? singular : plural}`;
}
