import {
  allowedPlayerCounts,
  defaultOptions,
  isPlayerCountAllowed,
  type GameOptions,
  type OptionsSpec,
  type OptionValue,
  type PlayerCountSpec,
} from "@gamehearth/sdk/platform";
import { rmSync } from "node:fs";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { buildWorker, bundleGameModule, verifyGameBuild } from "./bundle";
import { inspectClient } from "./client-files";
import { replayInQuickJs } from "./engine";
import { FindingCollector, type Finding } from "./findings";
import { validateManifest, type Manifest } from "./manifest";
import { runJobs, type PoolResult } from "./pool";
import { scanSoloClient } from "./solo-scan";
import { defaultMaxSeconds, type GameRun } from "./runner";
import { tickRate } from "@gamehearth/sdk/platform";
import type { Job } from "./worker";

export interface CheckOptions {
  games?: number;
  maxMoves?: number;
  maxSeconds?: number;
  maxTestedPlayers?: number;
  seed?: string;
  players?: number;
  options?: Record<string, string>;
  timeoutMs?: number;
  quickjsGames?: number;
  onProgress?: (playerCount: number, done: number, total: number) => void;
}

export interface CountSummary {
  playerCount: number;
  games: number;
  finished: number;
  tooLong: number;
  failed: number;
  averageMoves: number;
  longest: number;
  averageSeconds?: number;
  longestSeconds?: number;
  wins: Record<string, number>;
  withoutWinner: number;
  shared: number;
}

export interface CheckReport {
  gameDir: string;
  manifest?: Manifest;
  settings: { maxMoves: number; maxSeconds: number; timeoutMs: number };
  notes: string[];
  findings: Finding[];
  summaries: CountSummary[];
  replay?: GameRun;
}

export const defaultGames = 200;
export const defaultRealtimeGames = 20;
export const defaultRealtimeQuickJsGames = 2;
export { defaultMaxSeconds };
export const defaultMaxMoves = 5000;
export const defaultMaxTestedPlayers = 8;
export const defaultTimeoutMs = 3000;
export const maxTooLongPerCount = 3;
export const defaultQuickJsGames = 10;

export async function checkGame(gameDir: string, options: CheckOptions = {}): Promise<CheckReport> {
  const dir = resolve(gameDir);
  const settings = {
    maxMoves: options.maxMoves ?? defaultMaxMoves,
    maxSeconds: options.maxSeconds ?? defaultMaxSeconds,
    timeoutMs: options.timeoutMs ?? defaultTimeoutMs,
  };
  const report: CheckReport = { gameDir: dir, settings, notes: [], findings: [], summaries: [] };
  const findings = new FindingCollector();
  const done = () => {
    report.findings = findings.list();
    return report;
  };

  const manifest = await readManifest(dir, findings);
  if (manifest === undefined) {
    return done();
  }
  report.manifest = manifest;
  const client = await inspectClient(dir, manifest.client);
  if (!client.ok) {
    for (const problem of client.problems) {
      findings.add({ severity: "error", kind: "client", message: problem });
    }
  }
  if (!manifest.server) {
    report.notes.push("Das Spiel hat keinen Reducer (server: false). Bot-Partien entfallen; geprüft werden Manifest, Client und der Quelltext auf Dinge, die im abgeschotteten iframe scheitern.");
    for (const finding of await scanSoloClient(dir, manifest)) {
      findings.add(finding);
    }
    return done();
  }
  const realtime = manifest.mode === "realtime";
  if (options.players !== undefined && !isPlayerCountAllowed(manifest.players, options.players, Number.MAX_SAFE_INTEGER)) {
    findings.add({
      severity: "error",
      kind: "players",
      message: `Laut manifest.json sind ${options.players} Spieler nicht erlaubt (players: ${JSON.stringify(manifest.players)}).`,
    });
    return done();
  }
  const chosen = chosenOptions(manifest.options, options.options ?? {});
  if (typeof chosen === "string") {
    findings.add({ severity: "error", kind: "options", message: chosen });
    return done();
  }
  try {
    await verifyGameBuild(dir);
  } catch (error) {
    findings.add({ severity: "error", kind: "load", message: `Das Spiel lässt sich nicht bauen: ${describe(error)}` });
    return done();
  }

  const workDir = await mkdtemp(join(tmpdir(), "gamehearth-check-"));
  const cleanup = () => rmSync(workDir, { recursive: true, force: true });
  process.once("exit", cleanup);
  try {
    const workerFile = join(workDir, "worker.mjs");
    try {
      await buildWorker(dir, workerFile);
    } catch (error) {
      findings.add({ severity: "error", kind: "load", message: buildProblem(error) });
      return done();
    }
    const pool = { ...settings, maxTooLong: maxTooLongPerCount, maxTicks: settings.maxSeconds * tickRate, realtime };

    if (options.seed !== undefined) {
      const playerCount = options.players ?? manifest.players.min;
      const job: Job = { playerCount, seed: options.seed, decoyPlayerCount: decoyFor(playerCount, manifest.players), ...jobOptions(chosen ?? defaultOptions(manifest.options)) };
      const result = await runJobs(workerFile, [job], {
        ...pool,
        streamMoves: true,
        forwardOutput: true,
      });
      findings.addAll(result.findings);
      const run = result.runs[0];
      if (run !== undefined) {
        findings.addAll(run.findings);
        report.replay = run;
        if ((options.quickjsGames ?? (realtime ? defaultRealtimeQuickJsGames : defaultQuickJsGames)) > 0) {
          findings.addAll(await replayInQuickJs(await bundleGameModule(dir), [run]));
        }
      }
      return done();
    }

    const cap = options.maxTestedPlayers ?? defaultMaxTestedPlayers;
    const counts = options.players !== undefined ? [options.players] : countsToTest(manifest.players, cap);
    if (counts.length === 0) {
      findings.add({ severity: "error", kind: "players", message: "Laut manifest.json ist keine Spielerzahl erlaubt, es konnte keine Partie geprüft werden." });
      return done();
    }
    if (options.players === undefined && counts.some((count) => count > cap)) {
      report.notes.push(`Zwischen ${cap} und ${Math.max(...counts)} Spielern werden nur Minimum und Maximum geprüft.`);
    } else if (options.players === undefined && manifest.players.max === undefined) {
      report.notes.push(`Das Manifest nennt kein Maximum; geprüft werden höchstens ${cap} Spieler.`);
    }
    const variants = chosen === undefined ? optionVariants(manifest.options) : [chosen];
    const games = Math.max(options.games ?? (realtime ? defaultRealtimeGames : defaultGames), variants.length);
    if (variants.length > 1) {
      report.notes.push(
        `Optionen: Je Spielerzahl laufen ${variants.length} Varianten im Wechsel, einmal alle Optionen auf Standard und dann jeder andere Wert einer Option einmal, die übrigen auf Standard.`,
      );
    }
    if (realtime) {
      report.notes.push(
        `Echtzeit: Bots drücken in jedem Tick mit 20 % Wahrscheinlichkeit eine zufällige erlaubte Eingabe; eine Partie darf höchstens ${settings.maxSeconds} Sekunden Spielzeit dauern.`,
      );
    }
    const results = await Promise.all(
      counts.map((playerCount) => {
        const decoyPlayerCount = decoyFor(playerCount, manifest.players);
        const jobs: Job[] = Array.from({ length: games }, (_, index) => ({
          playerCount,
          seed: `check-${playerCount}-${index}`,
          decoyPlayerCount,
          ...jobOptions(variants[index % variants.length] as GameOptions),
        }));
        let finished = 0;
        return runJobs(workerFile, jobs, {
          ...pool,
          onRun: () => {
            finished += 1;
            options.onProgress?.(playerCount, finished, games);
          },
        });
      }),
    );
    results.forEach((result, index) => {
      collect(counts[index] as number, result, games, report, findings);
    });
    const quickjsGames = options.quickjsGames ?? (realtime ? defaultRealtimeQuickJsGames : defaultQuickJsGames);
    if (quickjsGames > 0) {
      const code = await bundleGameModule(dir);
      let replayed = 0;
      for (const result of results) {
        const runs = quickjsRuns(result.runs, quickjsGames);
        replayed += runs.length;
        findings.addAll(await replayInQuickJs(code, runs));
      }
      report.notes.push(`${replayed} Partien zusätzlich in QuickJS nachgespielt, der JS-Engine des Servers.`);
    }
    return done();
  } finally {
    process.removeListener("exit", cleanup);
    await rm(workDir, { recursive: true, force: true });
  }
}

function collect(playerCount: number, result: PoolResult, games: number, report: CheckReport, findings: FindingCollector): void {
  const summary = summarize(playerCount, result.runs);
  const variantOf = (run: GameRun) => JSON.stringify(run.options ?? {});
  const runsByVariant = new Map<string, GameRun[]>();
  for (const run of result.runs) {
    runsByVariant.set(variantOf(run), [...(runsByVariant.get(variantOf(run)) ?? []), run]);
  }
  const mostlyEndless = new Set(
    [...runsByVariant].filter(([, runs]) => {
      const tooLong = runs.filter((run) => run.ending === "too-long").length;
      return tooLong > 0 && tooLong * 2 >= runs.length;
    }).map(([variant]) => variant),
  );
  findings.addAll(result.findings);
  for (const run of result.runs) {
    for (const finding of run.findings) {
      findings.add(finding.kind === "never-ends" && mostlyEndless.has(variantOf(run)) ? { ...finding, severity: "error" } : finding);
    }
  }
  if (result.stoppedEarly === "hangs") {
    report.notes.push(`Bei ${playerCount} Spielern wurden nach wiederholtem Hängen die übrigen Partien übersprungen.`);
  }
  if (result.stoppedEarly === "too-long") {
    report.notes.push(
      `Bei ${playerCount} Spielern wurden nach ${maxTooLongPerCount} Partien ohne Ende die übrigen ${games - summary.games} übersprungen.`,
    );
  }
  const byVariant = new Map<string, GameRun[]>();
  for (const run of result.runs) {
    if (run.setupFingerprint !== undefined) {
      const key = JSON.stringify(run.options ?? {});
      byVariant.set(key, [...(byVariant.get(key) ?? []), run]);
    }
  }
  const sameStart = [...byVariant.values()].some(
    (setups) => setups.length >= 3 && setups.every((run) => run.setupUsedRandom === true) && new Set(setups.map((run) => run.setupFingerprint)).size === 1,
  );
  if (sameStart) {
    findings.add({
      severity: "warning",
      kind: "suspicious",
      message:
        "setup benutzt ctx.random, liefert aber bei jedem Seed denselben Startzustand. Meist wird das Ergebnis verworfen: random.shuffle(liste) mischt nicht die Liste selbst, sondern gibt eine gemischte Kopie zurück.",
      playerCount,
    });
  }
  report.summaries.push(summary);
}

export function quickjsRuns(runs: readonly GameRun[], count: number): GameRun[] {
  const sorted = [...runs].sort((a, b) => a.seed.localeCompare(b.seed, "en", { numeric: true }));
  const picked = new Set(sorted.slice(0, count));
  const variants = new Set([...picked].map((run) => JSON.stringify(run.options ?? {})));
  for (const run of sorted) {
    const variant = JSON.stringify(run.options ?? {});
    if (!variants.has(variant)) {
      variants.add(variant);
      picked.add(run);
    }
  }
  return sorted.filter((run) => picked.has(run));
}

export function optionVariants(spec: OptionsSpec | undefined): GameOptions[] {
  const base = defaultOptions(spec);
  const variants: GameOptions[] = [base];
  for (const [name, option] of Object.entries(spec ?? {})) {
    const values: OptionValue[] = option.type === "boolean" ? [true, false] : option.choices.map((choice) => choice.value);
    for (const value of values) {
      if (value !== option.default) {
        variants.push({ ...base, [name]: value });
      }
    }
  }
  return variants;
}

export function chosenOptions(spec: OptionsSpec | undefined, raw: Readonly<Record<string, string>>): GameOptions | undefined | string {
  const names = Object.keys(raw);
  if (names.length === 0) {
    return undefined;
  }
  const chosen: Record<string, OptionValue> = { ...defaultOptions(spec) };
  for (const name of names) {
    const option = spec !== undefined && Object.hasOwn(spec, name) ? spec[name] : undefined;
    const text = raw[name] as string;
    if (option === undefined) {
      const known = Object.keys(spec ?? {});
      return known.length === 0
        ? `--option ${name}: Das Spiel hat keine Optionen (options in manifest.json).`
        : `--option ${name}: Diese Option gibt es nicht, bekannt sind ${known.join(", ")}.`;
    }
    const values: OptionValue[] = option.type === "boolean" ? [true, false] : option.choices.map((choice) => choice.value);
    const value = values.find((candidate) => String(candidate) === text);
    if (value === undefined) {
      return `--option ${name}=${text}: Diesen Wert gibt es nicht, möglich sind ${values.map(String).join(", ")}.`;
    }
    chosen[name] = value;
  }
  return chosen;
}

function jobOptions(options: GameOptions): { options?: GameOptions } {
  return Object.keys(options).length === 0 ? {} : { options };
}

export function countsToTest(spec: PlayerCountSpec, cap: number): number[] {
  const upper = Math.max(cap, spec.max ?? spec.min, spec.min);
  const all = allowedPlayerCounts(spec, upper);
  const first = all[0];
  const last = spec.max === undefined ? undefined : all.at(-1);
  return all.filter((count) => count <= cap || count === first || count === last);
}

function decoyFor(playerCount: number, spec: PlayerCountSpec): number {
  const options = allowedPlayerCounts(spec, Math.max(spec.max ?? spec.min, spec.min, defaultMaxTestedPlayers));
  return options.find((count) => count !== playerCount) ?? playerCount;
}

async function readManifest(dir: string, findings: FindingCollector): Promise<Manifest | undefined> {
  let text: string;
  try {
    text = await readFile(join(dir, "manifest.json"), "utf8");
  } catch {
    findings.add({ severity: "error", kind: "manifest", message: `manifest.json fehlt in ${dir}` });
    return undefined;
  }
  let raw: unknown;
  try {
    raw = JSON.parse(text.replace(/^﻿/, ""));
  } catch (error) {
    findings.add({ severity: "error", kind: "manifest", message: `manifest.json ist kein gültiges JSON: ${describe(error)}` });
    return undefined;
  }
  const checked = validateManifest(raw);
  if (!checked.ok) {
    for (const problem of checked.problems) {
      findings.add({ severity: "error", kind: "manifest", message: `manifest.json: ${problem}` });
    }
    return undefined;
  }
  return checked.manifest;
}

function buildProblem(error: unknown): string {
  const message = describe(error);
  if (/default/.test(message) && /export/i.test(message)) {
    return "src/index.ts hat keinen default-Export. Das Spiel muss so exportiert werden: export default defineGame({ setup, legalMoves, apply, result })";
  }
  return `Das Spiel lässt sich nicht bauen: ${message}`;
}

function summarize(playerCount: number, runs: readonly GameRun[]): CountSummary {
  const finished = runs.filter((run) => run.ending === "finished");
  const lengths = runs.map((run) => run.moves.length);
  const seconds = runs.filter((run) => run.ticks !== undefined).map((run) => (run.ticks ?? 0) / tickRate);
  const wins: Record<string, number> = {};
  let withoutWinner = 0;
  let shared = 0;
  for (const run of finished) {
    const winners = run.result?.winners ?? [];
    if (winners.length === 0) {
      withoutWinner += 1;
    }
    if (winners.length > 1) {
      shared += 1;
    }
    for (const winner of winners) {
      wins[winner] = (wins[winner] ?? 0) + 1;
    }
  }
  return {
    playerCount,
    games: runs.length,
    finished: finished.length,
    tooLong: runs.filter((run) => run.ending === "too-long").length,
    failed: runs.filter((run) => run.ending === "failed").length,
    averageMoves: lengths.length === 0 ? 0 : Math.round(lengths.reduce((sum, length) => sum + length, 0) / lengths.length),
    longest: Math.max(0, ...lengths),
    ...(seconds.length === 0
      ? {}
      : { averageSeconds: Math.round(seconds.reduce((sum, value) => sum + value, 0) / seconds.length), longestSeconds: Math.round(Math.max(...seconds)) }),
    wins,
    withoutWinner,
    shared,
  };
}

function describe(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}
