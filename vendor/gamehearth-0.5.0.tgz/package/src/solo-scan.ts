import { readdir, readFile } from "node:fs/promises";
import { join, relative } from "node:path";
import type { Finding } from "./findings";
import type { Manifest } from "./manifest";

const sourcePattern = /\.(ts|tsx|js|jsx|mjs|cjs|mts|cts|vue|svelte)$/;
const skippedDirs = new Set(["node_modules", "dist", "build", ".git", ".gamehearth", "test", "tests", "coverage"]);
const maxFiles = 2000;
const maxFileBytes = 1024 * 1024;

interface Trap {
  pattern: RegExp;
  message: string;
}

const traps: Trap[] = [
  {
    pattern: /\b(localStorage|sessionStorage)\b/,
    message: "nutzt localStorage oder sessionStorage; im abgeschotteten iframe gibt es beides nicht. Spielstände gehen über game.save() und game.saved.",
  },
  { pattern: /\bindexedDB\b/, message: "nutzt indexedDB; im abgeschotteten iframe gibt es das nicht. Spielstände gehen über game.save() und game.saved." },
  { pattern: /\bdocument\.cookie\b/, message: "nutzt document.cookie; im abgeschotteten iframe gibt es keine Cookies." },
  { pattern: /\bnavigator\.serviceWorker\b|\bcaches\.open\b/, message: "nutzt einen Service Worker oder die Cache-API; offline lädt die Plattform das Spiel selbst." },
  {
    pattern: /\bnew\s+(WebSocket|EventSource|RTCPeerConnection)\b/,
    message: "baut eine eigene Verbindung auf; Spiele sprechen nur über das SDK mit der Plattform, die CSP sperrt Verbindungen nach außen.",
  },
  {
    pattern: /(\bfetch|\bXMLHttpRequest|\.load\.\w+)\s*\([^)]*["'`]https?:\/\//,
    message: "lädt etwas von einer fremden Adresse; die CSP erlaubt nur Dateien aus dem eigenen Client-Ordner. Lege Grafik und Daten ins Spiel.",
  },
];

const connectImport = /import\s*(type\s*)?\{[^}]*\bconnect\b[^}]*\}\s*from\s*["']@gamehearth\/sdk\/client["']/;
const recordCall = /([A-Za-z_$#][\w$]*)\s*\.\s*record\(\s*["'`]([^"'`]+)["'`]/g;
const receiverPatterns = [/(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*await\s+connectSolo\b/g, /(#?[A-Za-z_$][\w$]*)\s*[?!]?\s*:\s*SoloGame\b/g];

export async function scanSoloClient(gameDir: string, manifest: Manifest): Promise<Finding[]> {
  const files = await sourceFiles(gameDir, manifest.client);
  const findings: Finding[] = [];
  const stats = manifest.stats ?? {};
  let usesSolo = false;
  const texts = new Map<string, string>();
  const receivers = new Set<string>();
  for (const file of files) {
    try {
      const text = await readFile(file, "utf8");
      texts.set(file, text);
      for (const pattern of receiverPatterns) {
        for (const match of text.matchAll(pattern)) {
          receivers.add(match[1] as string);
        }
      }
    } catch {
      continue;
    }
  }
  for (const [file, text] of texts) {
    const name = relative(gameDir, file).split("\\").join("/");
    const lines = text.split(/\r?\n/);
    if (text.includes("connectSolo")) {
      usesSolo = true;
    }
    lines.forEach((line, index) => {
      const code = /^\s*(\/\/|\/\*|\*)/.test(line) ? "" : line;
      for (const trap of traps) {
        if (trap.pattern.test(code)) {
          findings.push({ severity: "warning", kind: "sandbox", message: `${name}:${index + 1} ${trap.message}`, detail: line.trim().slice(0, 160) });
        }
      }
      for (const match of code.matchAll(recordCall)) {
        const receiver = match[1] as string;
        const stat = match[2] as string;
        const sure = receivers.has(receiver);
        if (Object.hasOwn(stats, stat) || (!sure && receivers.size > 0)) {
          continue;
        }
        const known = Object.keys(stats);
        findings.push({
          severity: sure ? "error" : "warning",
          kind: "solo",
          message: `${name}:${index + 1} meldet ${sure ? "" : "vermutlich "}den Bestwert "${stat}", der nicht unter stats in manifest.json steht (${known.length === 0 ? "dort steht noch keiner" : `bekannt: ${known.join(", ")}`}). Die Plattform lehnt ihn ab.`,
        });
      }
    });
    if (connectImport.test(text)) {
      findings.push({
        severity: "error",
        kind: "solo",
        message: `${name} importiert connect aus @gamehearth/sdk/client. Einzelspieler ohne Reducer rufen connectSolo() auf; connect() lehnt die Plattform auf der Einzelspieler-Seite ab.`,
      });
    }
  }
  if (!usesSolo && files.length > 0) {
    findings.push({
      severity: "warning",
      kind: "solo",
      message: "Kein Quelltext ruft connectSolo() auf. Ohne kann das Spiel weder speichern noch Bestwerte melden; ist das gewollt, kann diese Warnung bleiben.",
    });
  }
  return findings;
}

async function sourceFiles(gameDir: string, clientDir: string): Promise<string[]> {
  const skippedPath = join(gameDir, ...clientDir.split("/"));
  const found: string[] = [];
  const walk = async (dir: string) => {
    if (found.length >= maxFiles || dir === skippedPath) {
      return;
    }
    let entries;
    try {
      entries = await readdir(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
      const path = join(dir, entry.name);
      if (entry.isDirectory()) {
        if (!skippedDirs.has(entry.name) && !entry.name.startsWith(".")) {
          await walk(path);
        }
      } else if (entry.isFile() && sourcePattern.test(entry.name) && !/\.(test|spec)\.[^.]+$/.test(entry.name) && !entry.name.endsWith(".d.ts")) {
        found.push(path);
      }
    }
  };
  await walk(gameDir);
  const sized: string[] = [];
  for (const file of found) {
    const text = await readFile(file).catch(() => undefined);
    if (text !== undefined && text.length <= maxFileBytes) {
      sized.push(file);
    }
  }
  return sized;
}
