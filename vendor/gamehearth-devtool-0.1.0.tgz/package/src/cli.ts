import { existsSync } from "node:fs";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import { addToCatalog, formatCatalog, parseCatalog, versionEntry, type Catalog } from "./catalog";
import { checkGame, type CheckOptions } from "./check";
import { download } from "./download";
import { formatReport } from "./format";
import { buildPackage, inspectPackage, maxPackageBytes, PackageError, sha256 } from "./package";

const usage = `Gamehearth-Werkzeug

Aufruf:
  gamehearth check <spielordner> [Optionen]
  gamehearth pack <spielordner> [--out <ordner>]
  gamehearth catalog add <catalog.json> <paket-adresse> [--name <katalogname>] [--replace]
  gamehearth catalog check <catalog.json> [--download]

pack prüft das Spiel mit check und baut nur ohne Fehler das Spielpaket
<id>-<version>.zip (Standard: <spielordner>/dist).

catalog add lädt ein Paket, prüft es wie der Server und trägt die Version mit
Größe und Prüfsumme in den Katalog ein. --name braucht es nur für einen neuen
Katalog, --replace ersetzt eine schon eingetragene Version.

catalog check prüft die Form des Katalogs, mit --download auch jedes Paket.

Optionen für check:
  --games <n>       Partien pro Spielerzahl (Standard 200)
  --players <n>     nur diese Spielerzahl prüfen
  --seed <seed>     genau eine Partie nachspielen und alle Züge zeigen (mit --players)
  --max-moves <n>   Züge, nach denen eine Partie als „endet nicht“ gilt (Standard 5000)
  --timeout <ms>    Zeit ohne Fortschritt, nach der Spielcode als hängend gilt (Standard 3000)
  --quickjs <n>     Partien pro Spielerzahl, die zusätzlich in QuickJS wie auf dem Server laufen (Standard 10, 0 schaltet ab)
  --json            Bericht als JSON ausgeben`;

const downloadLimits = { maxBytes: maxPackageBytes, timeoutMs: 120_000 };

async function main(args: string[]): Promise<number> {
  const [command, ...rest] = args;
  try {
    if (command === "check") {
      return await check(rest);
    }
    if (command === "pack") {
      return await pack(rest);
    }
    if (command === "catalog") {
      return await catalog(rest);
    }
  } catch (error) {
    if (error instanceof PackageError) {
      console.error(`Das Paket ist ungültig:\n${list(error.problems)}`);
      return 1;
    }
    console.error(error instanceof Error ? error.message : String(error));
    return 1;
  }
  console.error(usage);
  return 2;
}

function list(problems: readonly string[]): string {
  return problems.map((problem) => `  - ${problem}`).join("\n");
}

function wrongCall(problem?: string): number {
  console.error(problem === undefined ? usage : `${problem}\n\n${usage}`);
  return 2;
}

function flags(args: string[], known: Record<string, "value" | "switch">): { positional: string[]; values: Map<string, string | true> } | string {
  const positional: string[] = [];
  const values = new Map<string, string | true>();
  for (let index = 0; index < args.length; index++) {
    const arg = args[index] as string;
    if (!arg.startsWith("--")) {
      positional.push(arg);
      continue;
    }
    const kind = known[arg];
    if (kind === undefined) {
      return `Unbekannte Option ${arg}`;
    }
    if (kind === "switch") {
      values.set(arg, true);
      continue;
    }
    const value = args[index + 1];
    if (value === undefined) {
      return `${arg} braucht einen Wert`;
    }
    values.set(arg, value);
    index += 1;
  }
  return { positional, values };
}

async function pack(args: string[]): Promise<number> {
  const parsed = flags(args, { "--out": "value" });
  if (typeof parsed === "string") {
    return wrongCall(parsed);
  }
  if (parsed.positional.length !== 1) {
    return wrongCall();
  }
  const gameDir = resolve(parsed.positional[0] as string);
  const report = await checkGame(gameDir, {
    onProgress: (playerCount, done, total) => {
      if (done === total || done % 50 === 0) {
        process.stderr.write(`  ${playerCount} Spieler: ${done}/${total} Partien\n`);
      }
    },
  });
  const errors = report.findings.filter((finding) => finding.severity === "error").length;
  if (errors > 0) {
    console.log(formatReport(report));
    console.error(`pack bricht ab: check meldet ${errors} Fehler. Erst beheben, dann packen.`);
    return 1;
  }
  const warnings = report.findings.length - errors;
  const { archive, pkg } = await buildPackage(gameDir, { warnings });
  const out = resolve((parsed.values.get("--out") as string | undefined) ?? join(gameDir, "dist"));
  await mkdir(out, { recursive: true });
  const file = join(out, `${pkg.manifest.id}-${pkg.manifest.version}.zip`);
  await writeFile(file, archive);
  console.log(`Paket gebaut: ${file}`);
  console.log(`  Fassung  ${pkg.build}`);
  console.log(`  Größe    ${archive.length} Bytes`);
  console.log(`  SHA-256  ${sha256(archive)}`);
  console.log(`  check    ${warnings === 0 ? "ohne Warnungen" : `${warnings} ${warnings === 1 ? "Warnung" : "Warnungen"}`}`);
  return 0;
}

async function readCatalogFile(file: string): Promise<Catalog | undefined> {
  const checked = parseCatalog(await readFile(file, "utf8"));
  if (!checked.ok) {
    console.error(`${file} ist kein gültiger Katalog:\n${list(checked.problems)}`);
    return undefined;
  }
  return checked.catalog;
}

async function catalog(args: string[]): Promise<number> {
  const [sub, ...rest] = args;
  if (sub === "add") {
    return catalogAdd(rest);
  }
  if (sub === "check") {
    return catalogCheck(rest);
  }
  return wrongCall();
}

async function catalogAdd(args: string[]): Promise<number> {
  const parsed = flags(args, { "--name": "value", "--replace": "switch" });
  if (typeof parsed === "string") {
    return wrongCall(parsed);
  }
  if (parsed.positional.length !== 2) {
    return wrongCall();
  }
  const [file, url] = parsed.positional as [string, string];
  const name = parsed.values.get("--name");
  let current: Catalog;
  if (existsSync(file)) {
    const loaded = await readCatalogFile(file);
    if (loaded === undefined) {
      return 1;
    }
    current = typeof name === "string" ? { ...loaded, name } : loaded;
  } else {
    if (typeof name !== "string") {
      console.error(`${file} gibt es noch nicht. Für einen neuen Katalog --name <katalogname> angeben.`);
      return 2;
    }
    current = { format: 1, name, games: [] };
  }
  const archive = await download(url, downloadLimits);
  const pkg = inspectPackage(archive);
  const entry = versionEntry(pkg, archive, url);
  const next = addToCatalog(current, pkg, entry, { replace: parsed.values.get("--replace") === true });
  const checked = parseCatalog(formatCatalog(next));
  if (!checked.ok) {
    console.error(`Der Katalog wäre danach ungültig:\n${list(checked.problems)}`);
    return 1;
  }
  await writeFile(file, formatCatalog(next));
  console.log(
    next === current
      ? `${pkg.manifest.id} ${entry.version} steht schon so im Katalog.`
      : `${pkg.manifest.id} ${entry.version} eingetragen (${entry.size} Bytes, SHA-256 ${entry.sha256}, Fassung ${pkg.build}).`,
  );
  return 0;
}

async function catalogCheck(args: string[]): Promise<number> {
  const parsed = flags(args, { "--download": "switch" });
  if (typeof parsed === "string") {
    return wrongCall(parsed);
  }
  if (parsed.positional.length !== 1) {
    return wrongCall();
  }
  const file = parsed.positional[0] as string;
  const loaded = await readCatalogFile(file);
  if (loaded === undefined) {
    return 1;
  }
  let failures = 0;
  if (parsed.values.get("--download") === true) {
    for (const game of loaded.games) {
      for (const version of game.versions) {
        const label = `${game.id} ${version.version}`;
        try {
          const archive = await download(version.url, downloadLimits);
          const problems: string[] = [];
          if (archive.length !== version.size) {
            problems.push(`Größe ${archive.length} statt ${version.size}`);
          }
          if (sha256(archive) !== version.sha256) {
            problems.push("Prüfsumme stimmt nicht");
          }
          const pkg = inspectPackage(archive);
          if (pkg.manifest.id !== game.id || pkg.manifest.version !== version.version) {
            problems.push(`das Paket ist ${pkg.manifest.id} ${pkg.manifest.version}`);
          }
          if (problems.length > 0) {
            failures += 1;
            console.error(`${label}: ${problems.join("; ")}`);
          } else {
            console.log(`${label}: in Ordnung (${pkg.build})`);
          }
        } catch (error) {
          failures += 1;
          console.error(`${label}: ${error instanceof PackageError ? error.problems.join("; ") : error instanceof Error ? error.message : String(error)}`);
        }
      }
    }
  }
  const versions = loaded.games.reduce((sum, game) => sum + game.versions.length, 0);
  console.log(`${loaded.name}: ${loaded.games.length} Spiele, ${versions} Versionen${failures > 0 ? `, ${failures} fehlerhaft` : ""}`);
  return failures > 0 ? 1 : 0;
}

async function check(args: string[]): Promise<number> {
  const [gameDir, ...rest] = args;
  if (gameDir === undefined || gameDir.startsWith("--")) {
    console.error(usage);
    return 2;
  }
  const parsed = parseOptions(rest);
  if (typeof parsed === "string") {
    console.error(`${parsed}\n\n${usage}`);
    return 2;
  }
  const report = await checkGame(gameDir, {
    ...parsed.options,
    onProgress: (playerCount, done, total) => {
      if (done === total || done % 50 === 0) {
        process.stderr.write(`  ${playerCount} Spieler: ${done}/${total} Partien\n`);
      }
    },
  });
  console.log(parsed.json ? JSON.stringify(report, null, 2) : formatReport(report));
  return report.findings.some((finding) => finding.severity === "error") ? 1 : 0;
}

function parseOptions(args: string[]): { options: CheckOptions; json: boolean } | string {
  const options: CheckOptions = {};
  let json = false;
  for (let i = 0; i < args.length; i++) {
    const flag = args[i];
    if (flag === "--json") {
      json = true;
      continue;
    }
    const value = args[i + 1];
    if (value === undefined) {
      return `${flag} braucht einen Wert`;
    }
    i += 1;
    switch (flag) {
      case "--games":
      case "--players":
      case "--max-moves":
      case "--timeout": {
        const number = Number(value);
        if (!Number.isSafeInteger(number) || number < 1) {
          return `${flag} braucht eine ganze Zahl ab 1, bekam ${value}`;
        }
        if (flag === "--games") options.games = number;
        if (flag === "--players") options.players = number;
        if (flag === "--max-moves") options.maxMoves = number;
        if (flag === "--timeout") options.timeoutMs = number;
        break;
      }
      case "--quickjs": {
        const number = Number(value);
        if (!Number.isSafeInteger(number) || number < 0) {
          return `${flag} braucht eine ganze Zahl ab 0, bekam ${value}`;
        }
        options.quickjsGames = number;
        break;
      }
      case "--seed":
        options.seed = value;
        break;
      default:
        return `Unbekannte Option ${flag}`;
    }
  }
  return { options, json };
}

process.once("SIGINT", () => process.exit(130));
process.exitCode = await main(process.argv.slice(2));
