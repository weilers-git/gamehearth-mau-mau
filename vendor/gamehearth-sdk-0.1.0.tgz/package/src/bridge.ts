import { findNonJson } from "./json";
import { maxActionDepth, maxActionLength } from "./match";
import type { PlayerId } from "./state";

export const bridgeVersion = 1;

export interface PlayerInfo {
  name: string;
  connected: boolean;
  you: boolean;
}

export type MoveResult = { ok: true } | { ok: false; code: string; message: string };

export interface BridgeUpdate<Snapshot = unknown> {
  seat: PlayerId;
  role: "player";
  snapshot: Snapshot;
  players: Record<PlayerId, PlayerInfo>;
  online: boolean;
}

export type GameMessage =
  | { gamehearth: typeof bridgeVersion; type: "ready" }
  | { gamehearth: typeof bridgeVersion; type: "move"; id: number; action: unknown; expectedVersion: number };

export type PlatformMessage<Snapshot = unknown> =
  | ({ gamehearth: typeof bridgeVersion; type: "update" } & BridgeUpdate<Snapshot>)
  | ({ gamehearth: typeof bridgeVersion; type: "result"; id: number } & MoveResult);

export function parseGameMessage(data: unknown): GameMessage | undefined {
  if (!isRecord(data) || data["gamehearth"] !== bridgeVersion) {
    return undefined;
  }
  if (data["type"] === "ready") {
    return { gamehearth: bridgeVersion, type: "ready" };
  }
  if (data["type"] !== "move" || !isCounter(data["id"]) || !isCounter(data["expectedVersion"]) || !("action" in data)) {
    return undefined;
  }
  const action = data["action"];
  if (findNonJson(action, "action", maxActionDepth) !== undefined) {
    return undefined;
  }
  let serialized: string | undefined;
  try {
    serialized = JSON.stringify(action);
  } catch {
    return undefined;
  }
  if (serialized === undefined || serialized.length > maxActionLength) {
    return undefined;
  }
  return { gamehearth: bridgeVersion, type: "move", id: data["id"], action: JSON.parse(serialized) as unknown, expectedVersion: data["expectedVersion"] };
}

export function parsePlatformMessage(data: unknown): PlatformMessage | undefined {
  if (!isRecord(data) || data["gamehearth"] !== bridgeVersion) {
    return undefined;
  }
  if (data["type"] === "result") {
    if (!isCounter(data["id"])) {
      return undefined;
    }
    if (data["ok"] === true) {
      return { gamehearth: bridgeVersion, type: "result", id: data["id"], ok: true };
    }
    return data["ok"] === false && typeof data["code"] === "string" && typeof data["message"] === "string"
      ? { gamehearth: bridgeVersion, type: "result", id: data["id"], ok: false, code: data["code"], message: data["message"] }
      : undefined;
  }
  if (data["type"] !== "update" || typeof data["seat"] !== "string" || data["role"] !== "player" || typeof data["online"] !== "boolean") {
    return undefined;
  }
  const snapshot = data["snapshot"];
  if (!isRecord(snapshot) || !isCounter(snapshot["version"])) {
    return undefined;
  }
  const players = readPlayers(data["players"]);
  if (players === undefined) {
    return undefined;
  }
  return { gamehearth: bridgeVersion, type: "update", seat: data["seat"], role: "player", snapshot, players, online: data["online"] };
}

function readPlayers(raw: unknown): Record<PlayerId, PlayerInfo> | undefined {
  if (!isRecord(raw)) {
    return undefined;
  }
  const players: Record<PlayerId, PlayerInfo> = Object.create(null) as Record<PlayerId, PlayerInfo>;
  for (const [seat, info] of Object.entries(raw)) {
    if (!isRecord(info) || typeof info["name"] !== "string" || typeof info["connected"] !== "boolean" || typeof info["you"] !== "boolean") {
      return undefined;
    }
    players[seat] = { name: info["name"], connected: info["connected"], you: info["you"] };
  }
  return players;
}

function isCounter(value: unknown): value is number {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
