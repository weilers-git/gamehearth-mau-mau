export class DownloadError extends Error {}

export interface DownloadOptions {
  maxBytes: number;
  timeoutMs: number;
  fetch?: typeof fetch;
}

const maxRedirects = 5;
const redirects = new Set([301, 302, 303, 307, 308]);

export function isLoopbackHost(hostname: string): boolean {
  const host = hostname.toLowerCase().replace(/^\[|\]$/g, "");
  return host === "localhost" || host === "::1" || /^127\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(host);
}

export function downloadUrlProblem(raw: string): string | undefined {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return `${JSON.stringify(raw)} ist keine gültige Adresse`;
  }
  if (raw.length > 500) {
    return "Die Adresse ist länger als 500 Zeichen";
  }
  if (url.username !== "" || url.password !== "") {
    return "Adressen mit Benutzername oder Passwort sind nicht erlaubt";
  }
  if (url.protocol === "https:") {
    return undefined;
  }
  if (url.protocol === "http:" && isLoopbackHost(url.hostname)) {
    return undefined;
  }
  return `${url.origin} ist nicht erlaubt; Kataloge und Pakete kommen nur über https (http nur von localhost)`;
}

export async function download(url: string, options: DownloadOptions): Promise<Buffer> {
  const fetchFn = options.fetch ?? fetch;
  const signal = AbortSignal.timeout(options.timeoutMs);
  let current = url;
  for (let hop = 0; hop <= maxRedirects; hop++) {
    const problem = downloadUrlProblem(current);
    if (problem !== undefined) {
      throw new DownloadError(problem);
    }
    let response: Response;
    try {
      response = await fetchFn(current, { redirect: "manual", signal, headers: { "user-agent": "gamehearth" } });
    } catch (error) {
      throw new DownloadError(signal.aborted ? `Zeitlimit beim Laden von ${current}` : `${current} ist nicht erreichbar: ${describe(error)}`);
    }
    if (redirects.has(response.status)) {
      await response.body?.cancel();
      const location = response.headers.get("location");
      if (location === null) {
        throw new DownloadError(`${current} leitet um, nennt aber kein Ziel`);
      }
      const next = new URL(location, current);
      if (next.protocol !== "https:") {
        throw new DownloadError(`${current} leitet auf ${next.origin} um; Weiterleitungen gehen nur zu https`);
      }
      current = next.href;
      continue;
    }
    if (response.status !== 200) {
      await response.body?.cancel();
      throw new DownloadError(`${current} antwortet mit ${response.status}`);
    }
    return readLimited(response, current, options.maxBytes, signal);
  }
  throw new DownloadError(`${url} leitet mehr als ${maxRedirects}-mal um`);
}

async function readLimited(response: Response, url: string, maxBytes: number, signal: AbortSignal): Promise<Buffer> {
  const declared = Number(response.headers.get("content-length") ?? "NaN");
  const tooLarge = `${url} ist größer als ${formatLimit(maxBytes)}`;
  if (Number.isFinite(declared) && declared > maxBytes) {
    await response.body?.cancel();
    throw new DownloadError(tooLarge);
  }
  if (response.body === null) {
    return Buffer.alloc(0);
  }
  const reader = response.body.getReader();
  const chunks: Buffer[] = [];
  let total = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) {
        break;
      }
      total += value.byteLength;
      if (total > maxBytes) {
        await reader.cancel();
        throw new DownloadError(tooLarge);
      }
      chunks.push(Buffer.from(value));
    }
  } catch (error) {
    if (error instanceof DownloadError) {
      throw error;
    }
    throw new DownloadError(signal.aborted ? `Zeitlimit beim Laden von ${url}` : `Laden von ${url} abgebrochen: ${describe(error)}`);
  }
  return Buffer.concat(chunks);
}

function formatLimit(bytes: number): string {
  if (bytes >= 1024 * 1024) {
    return `${Math.round(bytes / 1024 / 1024)} MB`;
  }
  return bytes >= 1024 ? `${Math.round(bytes / 1024)} KB` : `${bytes} Bytes`;
}

function describe(error: unknown): string {
  if (error instanceof Error) {
    const cause = (error as Error & { cause?: unknown }).cause;
    return cause instanceof Error ? `${error.message} (${cause.message})` : error.message;
  }
  return String(error);
}
