import { createHash } from "node:crypto";
import { lstat, readdir, readFile, realpath } from "node:fs/promises";
import { isAbsolute, join, relative, sep } from "node:path";

export const maxClientBytes = 50 * 1024 * 1024;
export const maxClientFiles = 5000;
export const clientEntry = "index.html";

export interface ClientFile {
  path: string;
  size: number;
  sha256: string;
}

export type ClientInspection = { ok: true; dir: string; files: ClientFile[]; bytes: number } | { ok: false; problems: string[] };

export const safeSegment = /^[A-Za-z0-9._@+~-][A-Za-z0-9 ._@+~()-]*$/;

export function clientPathProblem(raw: unknown): string | undefined {
  if (typeof raw !== "string" || raw.trim() === "") {
    return 'client muss der Ordner mit dem gebauten Client sein, z. B. "dist/client"';
  }
  const segments = raw.replace(/\/+$/, "").split("/");
  if (isAbsolute(raw) || raw.includes("\\") || /^[A-Za-z]:/.test(raw) || segments.some((segment) => segment === "" || segment === "." || segment === "..")) {
    return `client muss ein Pfad innerhalb des Spielordners mit / als Trenner sein, bekam ${JSON.stringify(raw)}`;
  }
  return undefined;
}

export async function inspectClient(gameDir: string, clientPath: string): Promise<ClientInspection> {
  const pathProblem = clientPathProblem(clientPath);
  if (pathProblem !== undefined) {
    return { ok: false, problems: [pathProblem] };
  }
  const dir = join(gameDir, ...clientPath.replace(/\/+$/, "").split("/"));
  const missing = `Der Client-Ordner ${clientPath} fehlt. Baue die Oberfläche zuerst mit npm run build (npm run check und npm run pack in der Vorlage tun das selbst).`;
  let root: string;
  let gameRoot: string;
  try {
    const stats = await lstat(dir);
    if (stats.isSymbolicLink() || !stats.isDirectory()) {
      return { ok: false, problems: [stats.isSymbolicLink() ? `Der Client-Ordner ${clientPath} darf kein Verweis sein` : missing] };
    }
    root = await realpath(dir);
    gameRoot = await realpath(gameDir);
  } catch {
    return { ok: false, problems: [missing] };
  }
  const inside = relative(gameRoot, root);
  if (inside === "" || inside.startsWith("..") || isAbsolute(inside)) {
    return { ok: false, problems: [`Der Client-Ordner ${clientPath} liegt nicht innerhalb des Spielordners`] };
  }

  const problems: string[] = [];
  const files: ClientFile[] = [];
  let bytes = 0;
  const pending: string[] = [root];
  while (pending.length > 0 && problems.length === 0) {
    const current = pending.pop() as string;
    const entries = await readdir(current, { withFileTypes: true });
    for (const entry of entries) {
      const absolute = join(current, entry.name);
      const path = relative(root, absolute).split(sep).join("/");
      if (!safeSegment.test(entry.name)) {
        problems.push(`${clientPath}/${path}: Dateinamen dürfen nur Buchstaben, Ziffern, Leerzeichen und ._@+~()- enthalten`);
        break;
      }
      if (entry.isSymbolicLink()) {
        problems.push(`${clientPath}/${path} ist ein Verweis; im Client sind nur echte Dateien und Ordner erlaubt`);
        break;
      }
      if (entry.isDirectory()) {
        pending.push(absolute);
        continue;
      }
      if (!entry.isFile()) {
        problems.push(`${clientPath}/${path} ist keine normale Datei`);
        break;
      }
      const content = await readFile(absolute);
      bytes += content.length;
      files.push({ path, size: content.length, sha256: createHash("sha256").update(content).digest("hex") });
      if (files.length > maxClientFiles) {
        problems.push(`Der Client hat mehr als ${maxClientFiles} Dateien`);
        break;
      }
      if (bytes > maxClientBytes) {
        problems.push(`Der Client ist größer als ${maxClientBytes / 1024 / 1024} MB`);
        break;
      }
    }
  }
  if (problems.length === 0 && !files.some((file) => file.path === clientEntry)) {
    problems.push(`Im Client-Ordner ${clientPath} fehlt ${clientEntry}`);
  }
  if (problems.length > 0) {
    return { ok: false, problems };
  }
  files.sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0));
  return { ok: true, dir: root, files, bytes };
}
