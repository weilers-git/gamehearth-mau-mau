import { allowedPlayerCounts, isPlayerCountAllowed, type PlayerCountSpec } from "@gamehearth/sdk/platform";
import { rmSync } from "node:fs";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { buildWorker, bundleGameModule, verifyGameBuild } from "./bundle";
import { inspectClient } from "./client-files";
import { replayInQuickJs } from "./engine";
import { FindingCollector, type Finding } from "./findings";
import { validateManifest, type Manifest } from "./manifest";
import { runJobs, type PoolResult } from "./pool";
import type { GameRun } from "./runner";
import type { Job } from "./worker";

export interface CheckOptions {
  games?: number;
  maxMoves?: number;
  maxTestedPlayers?: number;
  seed?: string;
  players?: number;
  timeoutMs?: number;
  quickjsGames?: number;
  onProgress?: (playerCount: number, done: number, total: number) => void;
}

export interface CountSummary {
  playerCount: number;
  games: number;
  finished: number;
  tooLong: number;
  failed: number;
  averageMoves: number;
  longest: number;
  wins: Record<string, number>;
  withoutWinner: number;
}

export interface CheckReport {
  gameDir: string;
  manifest?: Manifest;
  settings: { maxMoves: number; timeoutMs: number };
  notes: string[];
  findings: Finding[];
  summaries: CountSummary[];
  replay?: GameRun;
}

export const defaultGames = 200;
export const defaultMaxMoves = 5000;
export const defaultMaxTestedPlayers = 8;
export const defaultTimeoutMs = 3000;
export const maxTooLongPerCount = 3;
export const defaultQuickJsGames = 10;

export async function checkGame(gameDir: string, options: CheckOptions = {}): Promise<CheckReport> {
  const dir = resolve(gameDir);
  const settings = { maxMoves: options.maxMoves ?? defaultMaxMoves, timeoutMs: options.timeoutMs ?? defaultTimeoutMs };
  const report: CheckReport = { gameDir: dir, settings, notes: [], findings: [], summaries: [] };
  const findings = new FindingCollector();
  const done = () => {
    report.findings = findings.list();
    return report;
  };

  const manifest = await readManifest(dir, findings);
  if (manifest === undefined) {
    return done();
  }
  report.manifest = manifest;
  const client = await inspectClient(dir, manifest.client);
  if (!client.ok) {
    for (const problem of client.problems) {
      findings.add({ severity: "error", kind: "client", message: problem });
    }
  }
  if (!manifest.server) {
    report.notes.push("Das Spiel hat keinen Reducer (server: false). Bot-Partien entfallen.");
    return done();
  }
  if (manifest.mode === "realtime") {
    report.notes.push("Echtzeit-Spiele prüft check noch nicht. Bot-Partien entfallen.");
    return done();
  }
  if (options.players !== undefined && !isPlayerCountAllowed(manifest.players, options.players, Number.MAX_SAFE_INTEGER)) {
    findings.add({
      severity: "error",
      kind: "players",
      message: `Laut manifest.json sind ${options.players} Spieler nicht erlaubt (players: ${JSON.stringify(manifest.players)}).`,
    });
    return done();
  }
  try {
    await verifyGameBuild(dir);
  } catch (error) {
    findings.add({ severity: "error", kind: "load", message: `Das Spiel lässt sich nicht bauen: ${describe(error)}` });
    return done();
  }

  const workDir = await mkdtemp(join(tmpdir(), "gamehearth-check-"));
  const cleanup = () => rmSync(workDir, { recursive: true, force: true });
  process.once("exit", cleanup);
  try {
    const workerFile = join(workDir, "worker.mjs");
    try {
      await buildWorker(dir, workerFile);
    } catch (error) {
      findings.add({ severity: "error", kind: "load", message: buildProblem(error) });
      return done();
    }
    const pool = { ...settings, maxTooLong: maxTooLongPerCount };

    if (options.seed !== undefined) {
      const playerCount = options.players ?? manifest.players.min;
      const result = await runJobs(workerFile, [{ playerCount, seed: options.seed, decoyPlayerCount: decoyFor(playerCount, manifest.players) }], {
        ...pool,
        streamMoves: true,
        forwardOutput: true,
      });
      findings.addAll(result.findings);
      const run = result.runs[0];
      if (run !== undefined) {
        findings.addAll(run.findings);
        report.replay = run;
        if ((options.quickjsGames ?? defaultQuickJsGames) > 0) {
          findings.addAll(await replayInQuickJs(await bundleGameModule(dir), [run]));
        }
      }
      return done();
    }

    const cap = options.maxTestedPlayers ?? defaultMaxTestedPlayers;
    const counts = options.players !== undefined ? [options.players] : countsToTest(manifest.players, cap);
    if (counts.length === 0) {
      findings.add({ severity: "error", kind: "players", message: "Laut manifest.json ist keine Spielerzahl erlaubt, es konnte keine Partie geprüft werden." });
      return done();
    }
    if (options.players === undefined && counts.some((count) => count > cap)) {
      report.notes.push(`Zwischen ${cap} und ${Math.max(...counts)} Spielern werden nur Minimum und Maximum geprüft.`);
    } else if (options.players === undefined && manifest.players.max === undefined) {
      report.notes.push(`Das Manifest nennt kein Maximum; geprüft werden höchstens ${cap} Spieler.`);
    }
    const games = options.games ?? defaultGames;
    const results = await Promise.all(
      counts.map((playerCount) => {
        const decoyPlayerCount = decoyFor(playerCount, manifest.players);
        const jobs: Job[] = Array.from({ length: games }, (_, index) => ({ playerCount, seed: `check-${playerCount}-${index}`, decoyPlayerCount }));
        let finished = 0;
        return runJobs(workerFile, jobs, {
          ...pool,
          onRun: () => {
            finished += 1;
            options.onProgress?.(playerCount, finished, games);
          },
        });
      }),
    );
    results.forEach((result, index) => {
      collect(counts[index] as number, result, games, report, findings);
    });
    const quickjsGames = options.quickjsGames ?? defaultQuickJsGames;
    if (quickjsGames > 0) {
      const code = await bundleGameModule(dir);
      let replayed = 0;
      for (const result of results) {
        const runs = [...result.runs].sort((a, b) => a.seed.localeCompare(b.seed, "en", { numeric: true })).slice(0, quickjsGames);
        replayed += runs.length;
        findings.addAll(await replayInQuickJs(code, runs));
      }
      report.notes.push(`${replayed} Partien zusätzlich in QuickJS nachgespielt, der JS-Engine des Servers.`);
    }
    return done();
  } finally {
    process.removeListener("exit", cleanup);
    await rm(workDir, { recursive: true, force: true });
  }
}

function collect(playerCount: number, result: PoolResult, games: number, report: CheckReport, findings: FindingCollector): void {
  const summary = summarize(playerCount, result.runs);
  const mostlyEndless = summary.tooLong > 0 && summary.tooLong * 2 >= summary.games;
  findings.addAll(result.findings);
  for (const run of result.runs) {
    for (const finding of run.findings) {
      findings.add(finding.kind === "never-ends" && mostlyEndless ? { ...finding, severity: "error" } : finding);
    }
  }
  if (result.stoppedEarly === "hangs") {
    report.notes.push(`Bei ${playerCount} Spielern wurden nach wiederholtem Hängen die übrigen Partien übersprungen.`);
  }
  if (result.stoppedEarly === "too-long") {
    report.notes.push(
      `Bei ${playerCount} Spielern wurden nach ${maxTooLongPerCount} Partien ohne Ende die übrigen ${games - summary.games} übersprungen.`,
    );
  }
  const setups = result.runs.filter((run) => run.setupFingerprint !== undefined);
  if (
    setups.length >= 3 &&
    setups.every((run) => run.setupUsedRandom === true) &&
    new Set(setups.map((run) => run.setupFingerprint)).size === 1
  ) {
    findings.add({
      severity: "warning",
      kind: "suspicious",
      message:
        "setup benutzt ctx.random, liefert aber bei jedem Seed denselben Startzustand. Meist wird das Ergebnis verworfen: random.shuffle(liste) mischt nicht die Liste selbst, sondern gibt eine gemischte Kopie zurück.",
      playerCount,
    });
  }
  report.summaries.push(summary);
}

export function countsToTest(spec: PlayerCountSpec, cap: number): number[] {
  const upper = Math.max(cap, spec.max ?? spec.min, spec.min);
  const all = allowedPlayerCounts(spec, upper);
  const first = all[0];
  const last = spec.max === undefined ? undefined : all.at(-1);
  return all.filter((count) => count <= cap || count === first || count === last);
}

function decoyFor(playerCount: number, spec: PlayerCountSpec): number {
  const options = allowedPlayerCounts(spec, Math.max(spec.max ?? spec.min, spec.min, defaultMaxTestedPlayers));
  return options.find((count) => count !== playerCount) ?? playerCount;
}

async function readManifest(dir: string, findings: FindingCollector): Promise<Manifest | undefined> {
  let text: string;
  try {
    text = await readFile(join(dir, "manifest.json"), "utf8");
  } catch {
    findings.add({ severity: "error", kind: "manifest", message: `manifest.json fehlt in ${dir}` });
    return undefined;
  }
  let raw: unknown;
  try {
    raw = JSON.parse(text.replace(/^﻿/, ""));
  } catch (error) {
    findings.add({ severity: "error", kind: "manifest", message: `manifest.json ist kein gültiges JSON: ${describe(error)}` });
    return undefined;
  }
  const checked = validateManifest(raw);
  if (!checked.ok) {
    for (const problem of checked.problems) {
      findings.add({ severity: "error", kind: "manifest", message: `manifest.json: ${problem}` });
    }
    return undefined;
  }
  return checked.manifest;
}

function buildProblem(error: unknown): string {
  const message = describe(error);
  if (/default/.test(message) && /export/i.test(message)) {
    return "src/index.ts hat keinen default-Export. Das Spiel muss so exportiert werden: export default defineGame({ setup, legalMoves, apply, result })";
  }
  return `Das Spiel lässt sich nicht bauen: ${message}`;
}

function summarize(playerCount: number, runs: readonly GameRun[]): CountSummary {
  const finished = runs.filter((run) => run.ending === "finished");
  const lengths = runs.map((run) => run.moves.length);
  const wins: Record<string, number> = {};
  let withoutWinner = 0;
  for (const run of finished) {
    const winners = run.result?.winners ?? [];
    if (winners.length === 0) {
      withoutWinner += 1;
    }
    for (const winner of winners) {
      wins[winner] = (wins[winner] ?? 0) + 1;
    }
  }
  return {
    playerCount,
    games: runs.length,
    finished: finished.length,
    tooLong: runs.filter((run) => run.ending === "too-long").length,
    failed: runs.filter((run) => run.ending === "failed").length,
    averageMoves: lengths.length === 0 ? 0 : Math.round(lengths.reduce((sum, length) => sum + length, 0) / lengths.length),
    longest: Math.max(0, ...lengths),
    wins,
    withoutWinner,
  };
}

function describe(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}
