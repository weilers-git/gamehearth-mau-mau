import type { GameDefinition, GameResult } from "./game";
import { canonicalJson, cloneJson, deepFreeze, findNonJson } from "./json";
import { SeededRandom, randomStateFromSeed, type RandomState } from "./random";
import { describeStateProblem, seatIds, type AnyGameState, type PlayerId } from "./state";

export const matchFormat = 1;
export const maxActionLength = 16_384;
export const maxActionDepth = 32;

export interface Match<S extends AnyGameState, A> {
  format: typeof matchFormat;
  seed: string;
  players: PlayerId[];
  state: S;
  moves: Record<PlayerId, A[]>;
  randomState: RandomState;
  version: number;
  result?: GameResult;
}

export interface CreateMatchOptions {
  playerCount: number;
  seed: string;
}

export interface Move<A> {
  player: PlayerId;
  action: A;
  now: number;
  expectedVersion?: number;
}

export type MatchErrorCode = "game-over" | "unknown-player" | "stale" | "not-your-turn" | "illegal-move" | "game-error";

export type GamePhase = "setup" | "legalMoves" | "apply" | "result";

export interface MatchError {
  code: MatchErrorCode;
  message: string;
  phase?: GamePhase;
  player?: PlayerId;
  stack?: string;
}

export type MatchOutcome<S extends AnyGameState, A> =
  | { ok: true; match: Match<S, A> }
  | { ok: false; error: MatchError };

type Failure = { ok: false; error: MatchError };
type Attempt<T> = { ok: true; value: T } | Failure;

interface Draft {
  seed: string;
  players: PlayerId[];
  state: unknown;
  randomState: RandomState;
  version: number;
  actor?: PlayerId;
}

export function createMatch<S extends AnyGameState, A>(
  game: GameDefinition<S, A>,
  options: CreateMatchOptions,
): MatchOutcome<S, A> {
  if (!Number.isSafeInteger(options.playerCount) || options.playerCount < 1) {
    throw new RangeError(`playerCount muss eine ganze Zahl ab 1 sein, bekam ${options.playerCount}`);
  }
  if (typeof options.seed !== "string" || options.seed.length === 0) {
    throw new TypeError("seed muss ein nicht leerer String sein");
  }
  const players = seatIds(options.playerCount);
  const random = new SeededRandom(randomStateFromSeed(options.seed));
  const setup = runGameCode("setup", undefined, () => game.setup({ players: [...players], random }));
  if (!setup.ok) {
    return setup;
  }
  return settle(game, "setup", {
    seed: options.seed,
    players,
    state: setup.value,
    randomState: random.state,
    version: 0,
  });
}

export function applyMove<S extends AnyGameState, A>(
  game: GameDefinition<S, A>,
  match: Match<S, A>,
  move: Move<A>,
): MatchOutcome<S, A> {
  if (match.format !== matchFormat) {
    throw new Error(`Unbekanntes Partie-Format ${String(match.format)}, erwartet ${matchFormat}`);
  }
  if (typeof move.now !== "number" || !Number.isFinite(move.now)) {
    throw new RangeError(`now muss ein Zeitpunkt in Millisekunden sein, bekam ${String(move.now)}`);
  }
  const checked = checkMove(match, move);
  if (!checked.ok) {
    return checked;
  }
  const chosen = checked.action;
  const random = new SeededRandom(match.randomState);
  const draft = cloneJson(match.state);
  const applied = runGameCode("apply", move.player, () =>
    game.apply(draft, cloneJson(chosen), {
      players: [...match.players],
      random,
      player: move.player,
      now: move.now,
    }),
  );
  if (!applied.ok) {
    return applied;
  }
  return settle(game, "apply", {
    seed: match.seed,
    players: [...match.players],
    state: applied.value === undefined ? draft : applied.value,
    randomState: random.state,
    version: match.version + 1,
    actor: move.player,
  });
}

export function checkMove<S extends AnyGameState, A>(
  match: Match<S, A>,
  move: Move<A>,
): { ok: true; action: A } | { ok: false; error: MatchError } {
  if (match.result !== undefined) {
    return failure("game-over", "die Partie ist bereits beendet");
  }
  if (!match.players.includes(move.player)) {
    return failure("unknown-player", `${String(move.player)} ist kein Sitz dieser Partie`);
  }
  if (move.expectedVersion !== undefined && move.expectedVersion !== match.version) {
    return failure(
      "stale",
      `der Zug bezieht sich auf Stand ${move.expectedVersion}, die Partie ist schon bei Stand ${match.version}`,
    );
  }
  const available = match.moves[move.player] ?? [];
  if (available.length === 0) {
    return failure("not-your-turn", `${move.player} kann gerade nicht ziehen`);
  }
  const wanted = canonicalAction(move.action);
  if (!wanted.ok) {
    return wanted;
  }
  const chosen = available.find((candidate) => canonicalJson(candidate) === wanted.value);
  if (chosen === undefined) {
    return failure("illegal-move", `dieser Zug ist für ${move.player} gerade nicht erlaubt`);
  }
  return { ok: true, action: chosen };
}

function canonicalAction(action: unknown): Attempt<string> {
  let serialized: string | undefined;
  try {
    serialized = JSON.stringify(action);
  } catch {
    return failure("illegal-move", "der Zug ist kein gültiger JSON-Wert");
  }
  if (serialized === undefined) {
    return failure("illegal-move", "der Zug fehlt");
  }
  if (serialized.length > maxActionLength) {
    return failure("illegal-move", `der Zug ist größer als ${maxActionLength} Zeichen`);
  }
  const problem = findNonJson(action, "action", maxActionDepth);
  if (problem !== undefined) {
    return failure("illegal-move", `${problem.path} ${problem.reason}`);
  }
  return { ok: true, value: canonicalJson(action) };
}

function settle<S extends AnyGameState, A>(
  game: GameDefinition<S, A>,
  phase: "setup" | "apply",
  draft: Draft,
): MatchOutcome<S, A> {
  try {
    return settleUnguarded(game, phase, draft);
  } catch (error) {
    return gameError(
      phase,
      draft.actor,
      `nach ${phase} ist ein unerwarteter Fehler aufgetreten: ${errorMessage(error)}`,
      errorStack(error),
    );
  }
}

function settleUnguarded<S extends AnyGameState, A>(
  game: GameDefinition<S, A>,
  phase: "setup" | "apply",
  draft: Draft,
): MatchOutcome<S, A> {
  const stateProblem = describeStateProblem(draft.state, draft.players);
  if (stateProblem !== undefined) {
    return gameError(phase, draft.actor, `${phase} hat einen ungültigen Zustand geliefert: ${stateProblem}`);
  }
  const state = cloneJson(draft.state) as S;
  const readOnly = deepFreeze(cloneJson(state));
  const base = {
    format: matchFormat,
    seed: draft.seed,
    players: draft.players,
    state,
    randomState: draft.randomState,
    version: draft.version,
  } as const;

  const result = runGameCode("result", undefined, () => game.result(readOnly));
  if (!result.ok) {
    return result;
  }
  if (result.value !== undefined && result.value !== null) {
    const resultProblem = describeResultProblem(result.value, draft.players);
    if (resultProblem !== undefined) {
      return gameError("result", undefined, `result hat ein ungültiges Ergebnis geliefert: ${resultProblem}`);
    }
    const moves = Object.fromEntries(draft.players.map((player) => [player, [] as A[]]));
    return { ok: true, match: { ...base, moves, result: { winners: [...result.value.winners] } } };
  }

  const moves: Record<PlayerId, A[]> = {};
  for (const player of draft.players) {
    const legal = runGameCode("legalMoves", player, () => game.legalMoves(readOnly, player));
    if (!legal.ok) {
      return legal;
    }
    if (!Array.isArray(legal.value)) {
      return gameError("legalMoves", player, `legalMoves für ${player} muss ein Array liefern`);
    }
    const problem = findNonJson(legal.value, `legalMoves(${player})`, maxActionDepth);
    if (problem !== undefined) {
      return gameError("legalMoves", player, `${problem.path} ${problem.reason}`);
    }
    const tooLarge = legal.value.findIndex((candidate) => JSON.stringify(candidate).length > maxActionLength);
    if (tooLarge !== -1) {
      return gameError(
        "legalMoves",
        player,
        `legalMoves(${player})[${tooLarge}] ist größer als ${maxActionLength} Zeichen und könnte nie gesendet werden`,
      );
    }
    moves[player] = cloneJson(legal.value);
  }
  if (draft.players.every((player) => (moves[player] ?? []).length === 0)) {
    return gameError(
      phase,
      draft.actor,
      `nach ${phase} kann niemand ziehen, aber result meldet kein Ende; die Partie würde für immer hängen`,
    );
  }
  return { ok: true, match: { ...base, moves } };
}

function describeResultProblem(result: unknown, players: readonly PlayerId[]): string | undefined {
  if (typeof result !== "object" || result === null || !Array.isArray((result as GameResult).winners)) {
    return "erwartet wird ein Objekt der Form { winners: [...] }";
  }
  const winners = (result as GameResult).winners;
  for (const winner of winners) {
    if (typeof winner !== "string" || !players.includes(winner)) {
      return `winners enthält ${JSON.stringify(winner)}, das ist kein Sitz dieser Partie (Sitze: ${players.join(", ")})`;
    }
  }
  if (new Set(winners).size !== winners.length) {
    return "winners enthält einen Sitz mehrfach";
  }
  return undefined;
}

function runGameCode<T>(phase: GamePhase, player: PlayerId | undefined, run: () => T): Attempt<T> {
  const label = phase === "legalMoves" && player !== undefined ? `legalMoves für ${player}` : phase;
  try {
    const value = run();
    if (isThenable(value)) {
      Promise.resolve(value).catch(() => undefined);
      return gameError(phase, player, `${label} darf nicht async sein und kein Promise zurückgeben`);
    }
    return { ok: true, value };
  } catch (error) {
    return gameError(phase, player, `${label} hat einen Fehler geworfen: ${errorMessage(error)}`, errorStack(error));
  }
}

function isThenable(value: unknown): value is PromiseLike<unknown> {
  return (
    value !== null &&
    (typeof value === "object" || typeof value === "function") &&
    typeof (value as { then?: unknown }).then === "function"
  );
}

function errorMessage(error: unknown): string {
  try {
    return error instanceof Error ? error.message : String(error);
  } catch {
    return "unbekannter Fehler";
  }
}

function errorStack(error: unknown): string | undefined {
  try {
    if (error instanceof Error && typeof error.stack === "string") {
      return error.stack.split("\n").slice(0, 8).join("\n");
    }
  } catch {
    return undefined;
  }
  return undefined;
}

function gameError(phase: GamePhase, player: PlayerId | undefined, message: string, stack?: string): Failure {
  const error: MatchError = { code: "game-error", message, phase };
  if (player !== undefined) {
    error.player = player;
  }
  if (stack !== undefined) {
    error.stack = stack;
  }
  return { ok: false, error };
}

function failure(code: MatchErrorCode, message: string): Failure {
  return { ok: false, error: { code, message } };
}
