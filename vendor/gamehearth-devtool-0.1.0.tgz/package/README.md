# @gamehearth/devtool

Werkzeug für Gamehearth-Spiele mit den Befehlen `check` (Spiel prüfen), `pack` (Spielpaket bauen) und `catalog` (Katalog pflegen). `new` und `dev` kommen mit dem Starter-Repo in Schritt 7b.

Im Monorepo startet es mit `npm run gamehearth -- <befehl>`, in einem Spiel- oder Katalog-Repo mit `npx gamehearth <befehl>` (dort liegt es bis zur Veröffentlichung auf npm als Tarball in `vendor/`).

## check

```bash
npm run gamehearth -- check fixtures/mau-mau
```

`check` prüft ein Spiel so, dass Fehler auffallen, bevor jemand damit spielt, und meldet sie so, dass ein KI-Agent sie direkt beheben kann.

1. **Manifest**: Pflichtfelder, Spielerzahl, Rollen, Lizenzen (OSI-Lizenz für Code, CC0/CC-BY/CC-BY-SA für Assets), unbekannte Felder (Tippfehler) und ob die verlangte SDK-Version (`"sdk": "^0.1.0"`) zum vorhandenen SDK passt. Optional sind `description` (1 bis 200 Zeichen, erscheint im Katalog) und `repository` (`https`-Adresse des Quelltexts). Eine Datei mit BOM, wie sie PowerShell gern schreibt, ist kein Problem.
2. **Client**: Der Ordner aus `"client"` im Manifest (etwa `"dist/client"`) muss gebaut sein, innerhalb des Spielordners liegen und eine `index.html` enthalten. Erlaubt sind höchstens 5000 Dateien und 50 MB, keine Verweise (Symlinks) und nur Dateinamen aus Buchstaben, Ziffern, Leerzeichen und `._@+~()-`. Fehlt der Ordner, meldet `check` das als Fehler und spielt trotzdem alle Partien.
3. **Bauen**: Das Spiel wird aus `src/index.ts` zu einer Datei gebündelt, genauso wie auf dem Server. Eingebunden werden dürfen nur Dateien aus dem Spielordner (Code und JSON-Daten) und das SDK; ein Import wie `../../package.json` oder ein absoluter Pfad bricht mit einer klaren Meldung ab. Node-Module wie `fs` sind in Spielen nicht erlaubt und fallen hier auf, ebenso ein fehlender `export default`.
4. **Bot-Partien**: 200 Partien mit Zufallsbots für jede erlaubte Spielerzahl bis 8, darüber nur Minimum und Maximum. Nach jedem Zug wird gespeichert und geladen. Gemeldet werden Fehler im Spielcode mit Phase, Sitz und Stacktrace. Der Stacktrace zeigt auf die Zeile im Spiel, Zeilen aus SDK und Werkzeug sind herausgefiltert.
5. **Verbotene Funktionen**: `Math.random()`, `Date.now()` (auch über `new Date(0).constructor` oder den Eigenschaftsdeskriptor), `new Date()` ohne Argument, `performance.now()` und `crypto.getRandomValues()`/`randomUUID()` werfen beim Prüfen sofort einen Fehler mit Hinweis auf `ctx.random` und `ctx.now`, auch schon beim Laden des Spiels. Ebenso alles, was von der Zeitzone des Rechners abhängt: Datumsmethoden mit Ortszeit wie `getHours()` oder `toString()`, `Date.parse()` und `new Date` mit Text oder mehreren Argumenten; erlaubt sind `new Date(zahl)`, `Date.UTC(...)` und die UTC-Methoden. Fängt das Spiel diesen Fehler mit `try`/`catch` ab, meldet `check` den Aufruf trotzdem.
6. **Determinismus**: Jede Partie wird aus Seed und Zügen wiederholt, dabei läuft zwischen den Zügen eine zweite Partie mit anderer Spielerzahl im selben Modul. Weicht ein Zustand ab, nennt `check` Zug und Stelle, etwa `match.state.public.count: beim ersten Durchlauf 6, beim Wiederholen 7`. Das findet Variablen außerhalb der Funktionen, auch solche, die sich `setup` merkt: Auf dem Server laufen viele Partien gleichzeitig im selben Modul.
7. **Partien ohne Ende**: Endet eine Partie nach 5.000 Zügen nicht, gibt es eine Warnung, bei der Mehrheit der Partien einen Fehler. Nach drei solchen Partien pro Spielerzahl werden die übrigen übersprungen.
8. **Endlosschleifen**: Die Partien laufen in Worker-Threads. Antwortet Spielcode länger als 3 Sekunden nicht, bricht `check` ab und meldet Phase, Sitz, Zug und Seed. Nach zwei hängenden Partien pro Spielerzahl werden die übrigen übersprungen.
9. **Verdächtiges**: Warnungen, wenn ein erlaubter Zug den Zustand überhaupt nicht ändert (meist fehlt ein `case` in `apply`) und wenn `setup` Zufall benutzt, aber bei jedem Seed denselben Start liefert (meist wurde das Ergebnis von `random.shuffle` verworfen).
10. **Lecks**: nach jedem Zug, siehe unten.
11. **Engine des Servers**: Der Server führt Spiele in QuickJS aus, nicht in Node. Je Spielerzahl spielt `check` deshalb die ersten 10 Partien zusätzlich in derselben Sandbox wie der Server nach (Vorspann, Zeitlimit 100 ms pro Aufruf, Speicherdeckel, Stack-Limit 256 KB) und vergleicht jeden Stand. Nach dem ersten Fehler hört das Nachspielen auf; eine harte Grenze wie im Server-Worker gibt es in `check` nicht, ein sehr langer Aufruf einer eingebauten Funktion hält den Prüflauf also auf. Scheitert eine Partie dort, ist das ein Fehler; typische Ursachen sind Funktionen, die es in QuickJS nicht gibt (`console`, `structuredClone`, `Intl`, `TextEncoder`, `atob`, `URL`), `eval` oder ein zu langsamer Zug. Läuft sie anders, gibt es eine Warnung; meist rechnen `Math.sin`, `Math.exp`, `Math.pow`, `Math.hypot` und Verwandte in den letzten Stellen anders, oder `localeCompare`, `toLocaleString` oder ein inkonsistenter Vergleicher für `sort` verhalten sich anders.

Die Partien sind selbst reproduzierbar: Gleicher Spielcode ergibt bei jedem Aufruf dieselben Partien. Zu jedem Fund steht der Befehl, mit dem sich genau diese Partie nachspielen lässt, inklusive abweichender Grenzen:

```bash
npm run gamehearth -- check fixtures/mau-mau --players 3 --seed check-3-17
```

Dann zeigt `check` alle Züge der Partie einzeln, auch bis zu einer Stelle, an der sie hängt, und gibt Ausgaben des Spiels (`console.log`) weiter. Im normalen Prüflauf werden diese Ausgaben verschluckt; der Fortschritt steht auf stderr.

### Lecks

**Züge (Fehler).** Für jeden Spieler vertauscht `check` nach jedem Zug die verdeckten Werte, also die Texte in `secret` und in den Bereichen der anderen Spieler, einschließlich Mengen der Form `{ "herz-7": true }`. Was der Spieler sieht, bleibt dabei gleich. Ändern sich seine erlaubten Züge, hängen sie von Daten ab, die er nicht sehen darf, und verraten sie an seinen Client. Ein Beispiel ist `{ type: "draw", card: "herz-7" }` mit der obersten Karte des Stapels. Eine feste Auswahl wie Schere, Stein, Papier oder alle möglichen Anklagen bei einem Detektivspiel ändert sich nicht und gilt deshalb nicht als Leck, auch wenn die geheime Lösung darin vorkommt.

**Kopien (Warnungen).** Außerdem sucht `check` Werte, die gleichzeitig offen und verdeckt liegen:

| Fund | Beispiel |
|---|---|
| Ein Wert steht gleichzeitig in `public` und in `secret` | `public.next = secret.deck.at(-1)` |
| Ein Wert steht gleichzeitig in `public` und im Bereich eines Spielers | eine Handkarte wird angezeigt, bleibt aber auf der Hand |
| Ein Wert steht im Bereich von p1 und gleichzeitig in `secret` oder bei p2 | p1 bekommt eine Karte von p2 als Kopie |

Als Werte zählen Texte ab 2 Zeichen (außer Sitznamen), Schlüssel von Mengen und kleine Objekte in Listen wie `{ "suit": "herz", "rank": 7 }`, die als Ganzes verglichen werden. Texte, die gerade als Wahlmöglichkeit in Zügen vorkommen, zählen nicht. Aufdecken verschiebt einen Wert normalerweise, statt ihn zu kopieren. Warnungen können trotzdem gewollt sein, etwa eine offen unter dem Stapel liegende Trumpfkarte oder eine Rolle, die ein Seher sehen darf.

Beides sind Heuristiken, keine Garantie. Zahlen und abgeleitete Werte (etwa „die Summe der Karten von p2“ in `public`) erkennen sie nicht.

### Optionen

| Option | Bedeutung |
|---|---|
| `--games <n>` | Partien pro Spielerzahl (Standard 200) |
| `--players <n>` | nur diese Spielerzahl prüfen (muss laut Manifest erlaubt sein) |
| `--seed <seed>` | genau eine Partie nachspielen (mit `--players`) |
| `--max-moves <n>` | Züge, nach denen eine Partie als „endet nicht“ gilt (Standard 5000) |
| `--timeout <ms>` | Zeit ohne Fortschritt, nach der Spielcode als hängend gilt (Standard 3000) |
| `--quickjs <n>` | Partien pro Spielerzahl, die zusätzlich in QuickJS laufen (Standard 10, 0 schaltet ab) |
| `--json` | Bericht als JSON |

Der Rückgabewert ist 0 ohne Fehler, 1 bei mindestens einem Fehler (Warnungen zählen nicht) und 2 bei falschem Aufruf.

### Grenzen

- Echtzeit-Spiele und Spiele ohne Reducer (`server: false`) werden noch nicht gespielt, nur ihr Manifest wird geprüft.
- Zufallsbots spielen nicht klug. Fehler, die nur in seltenen, gezielt herbeigeführten Situationen auftreten, können durchrutschen; dagegen helfen eigene Regeltests wie bei Mau-Mau.
- Die Verbote in Node gelten nur beim Prüfen. Auf dem Server sperrt der Vorspann der Sandbox dieselben Funktionen, zusätzlich `eval` und den `Function`-Konstruktor; `instanceof Function` und `Function.prototype` funktionieren dort weiter.

## pack

```bash
npx gamehearth pack . [--out <ordner>]
```

`pack` prüft das Spiel zuerst mit `check` (wie oben, mit allen Partien) und bricht bei Fehlern ab; Warnungen sind erlaubt und werden mitgezählt. Dann baut es das Spielpaket `<id>-<version>.zip` (Standard: `dist/` im Spielordner) und nennt Fassung, Größe und SHA-256. Der Client muss vorher gebaut sein (im Spiel-Repo erledigt das `npm run pack`).

Ein Spielpaket ist ein ZIP mit genau diesen Dateien:

| Datei | Inhalt |
|---|---|
| `manifest.json` | das Manifest, unverändert |
| `game.mjs` | der Reducer, mit esbuild gebündelt wie beim Prüfen (nur Dateien aus dem Spielordner und das SDK), Pflicht bei `server: true` |
| `client/…` | der gebaute Client-Ordner aus `"client"` mit `index.html`, höchstens 5000 Dateien und 50 MB |
| `LICENSE` | Pflicht, höchstens 256 KB |
| `README.md` | optional, höchstens 256 KB |
| `pack.json` | `{ "format": 1, "sdk", "devtool", "warnings" }`: Versionen beim Packen und Zahl der Warnungen von `check`; zählt nicht zum Hash |

Die Fassung heißt wie auf dem Server `<id>@<version>+<hash>`; der Hash läuft über das Manifest, `game.mjs` und alle Client-Dateien. `pack` schreibt das ZIP deterministisch (Einträge sortiert, feste Zeitstempel, immer gleich komprimiert): Derselbe Stand ergibt mit derselben Node-Version dieselbe Prüfsumme. Ganze Pakete sind höchstens 60 MB groß, `game.mjs` höchstens 5 MB.

Gelesen wird ein Paket streng (`inspectPackage`, `readZip`), auf dem Server wie in `catalog add`: nur Deflate oder unkomprimiert, keine Verschlüsselung, kein ZIP64, keine Ordner-Einträge, keine Verweise oder Gerätedateien, keine Pfade mit `..`, `\`, Doppelpunkt oder Steuerzeichen, keine doppelten Namen (auch nicht in anderer Groß- und Kleinschreibung), kein Kommentar, keine Daten vor, zwischen oder nach den Einträgen. Größen und Zahl der Einträge prüft der Leser, bevor er etwas entpackt, und danach die CRC. Alle Fehler eines Pakets kommen auf einmal.

## catalog

```bash
npx gamehearth catalog add catalog.json <paket-adresse> [--name <katalogname>] [--replace]
npx gamehearth catalog check catalog.json [--download]
```

Ein Katalog ist eine `catalog.json` (Format in `docs/design.md` unter „Spielpakete und Kataloge“): Name des Katalogs und pro Spiel `id`, Name, Beschreibung, Repo-Link und Versionen mit SDK-Bereich, Modus, Spielerzahl, Rollen, Lizenz, Größe, Adresse und SHA-256. Ein Katalog hat höchstens 500 Spiele mit je 50 Versionen und ist höchstens 1 MB groß.

`catalog add` lädt das Paket von der Adresse (nur `https`, `http` nur von localhost), prüft es wie der Server und trägt die Version mit Größe und Prüfsumme ein. Die Versionen stehen absteigend sortiert; Name, Beschreibung und Repo-Link kommen aus dem Manifest der neuesten Version. Steht dieselbe Version schon mit anderer Prüfsumme oder Adresse drin, bricht der Befehl ab, außer mit `--replace`. Für einen neuen Katalog braucht es `--name`.

`catalog check` prüft die Form der Datei; mit `--download` lädt es zusätzlich jedes Paket und vergleicht Größe, Prüfsumme, `id` und Version (so prüft die CI des Katalog-Repos).

## Sandbox

Unter `@gamehearth/devtool/sandbox` liegt der Sandbox-Kern, den Server und `check` gemeinsam nutzen: ein QuickJS-Modul (über `quickjs-emscripten` 0.32.0, fest gewählt, weil die Engine Teil der Spielfassung ist) mit eigenem, gedeckeltem WebAssembly-Speicher pro Sandbox, Vorspann, Gast-Runner und Prüfung der Ausgabe. Wie der Server ihn einsetzt, steht in [packages/server](../server/README.md#sandbox).
