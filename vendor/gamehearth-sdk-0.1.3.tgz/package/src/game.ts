import type { GameOptions, OptionsShape } from "./options";
import type { Random } from "./random";
import type { AnyGameState, PlayerId } from "./state";

export interface SetupContext<O extends OptionsShape<O> = GameOptions> {
  players: readonly PlayerId[];
  random: Random;
  options: O;
}

export interface MoveContext<O extends OptionsShape<O> = GameOptions> extends SetupContext<O> {
  player: PlayerId;
  now: number;
}

export interface TickContext<O extends OptionsShape<O> = GameOptions> extends SetupContext<O> {
  now: number;
}

export interface LegalMovesContext<O extends OptionsShape<O> = GameOptions> {
  players: readonly PlayerId[];
  options: O;
}

export interface GameResult {
  winners: PlayerId[];
}

export interface GameDefinition<S extends AnyGameState, A, O extends OptionsShape<O> = GameOptions> {
  setup(ctx: SetupContext<O>): S;
  legalMoves(state: S, player: PlayerId, ctx: LegalMovesContext<O>): A[];
  apply(state: S, action: A, ctx: MoveContext<O>): S | void;
  result(state: S): GameResult | undefined;
  tick?(state: S, dt: number, ctx: TickContext<O>): S | void;
}

export type DefinedGame<S extends AnyGameState, A, O extends OptionsShape<O> = GameOptions> = GameDefinition<S, A, O> & {
  legalMoves(state: S, player: PlayerId, ctx?: LegalMovesContext<O>): A[];
};

export function defineGame<S extends AnyGameState, A, O extends OptionsShape<O> = GameOptions>(game: GameDefinition<S, A, O>): DefinedGame<S, A, O> {
  return game as DefinedGame<S, A, O>;
}
