import { seatIds, type AnyGameState, type Match } from "@gamehearth/sdk/platform";
import type { Finding } from "./findings";
import { fingerprint, type GameRun } from "./runner";
import { buildGuestRunner } from "./sandbox/build";
import { Sandbox, sandboxDefaults, workerStackSizeBytes, type SandboxResult } from "./sandbox/sandbox";

const serverHint = `Dort fehlen unter anderem console, structuredClone, Intl, TextEncoder, atob und URL; eval, der Function-Konstruktor und Datumsmethoden mit Ortszeit sind gesperrt, und ein Aufruf darf höchstens ${sandboxDefaults.callTimeoutMs} ms dauern.`;

const divergence =
  "Auf dem Server (QuickJS) ergibt dieselbe Partie einen anderen Zustand als hier in Node. Häufige Ursachen: Math.sin, Math.cos, Math.exp, Math.pow, Math.hypot und Verwandte rechnen in den letzten Stellen anders; localeCompare und toLocaleString kennen dort kein Gebietsschema; ein Vergleicher für sort liefert nicht konsistent negativ, 0 oder positiv. Auf dem Server bleibt jede Partie in sich wiederholbar, aber check hat dort nicht genau diese Partien geprüft.";

export async function replayInQuickJs(code: string, runs: readonly GameRun[]): Promise<Finding[]> {
  const runner = await buildGuestRunner();
  const findings: Finding[] = [];
  for (const run of runs) {
    const fingerprints = run.fingerprints ?? [];
    if (fingerprints.length === 0) {
      continue;
    }
    const where = { playerCount: run.playerCount, seed: run.seed };
    let sandbox: Sandbox;
    try {
      sandbox = await Sandbox.create(runner, code, { maxStackSizeBytes: workerStackSizeBytes });
    } catch (error) {
      findings.push({
        severity: "error",
        kind: "engine",
        message: `Auf dem Server (QuickJS) lässt sich das Spiel nicht laden: ${error instanceof Error ? error.message : String(error)}. ${serverHint}`,
      });
      return findings;
    }
    try {
      const finding = replayOne(sandbox, run, fingerprints, where);
      if (finding !== undefined) {
        findings.push(finding);
        if (finding.severity === "error") {
          return findings;
        }
      }
    } finally {
      sandbox.dispose();
    }
  }
  return findings;
}

function replayOne(sandbox: Sandbox, run: GameRun, fingerprints: readonly string[], where: { playerCount: number; seed: string }): Finding | undefined {
  const players = seatIds(run.playerCount);
  let result = sandbox.run("createMatch", JSON.stringify({ playerCount: run.playerCount, seed: run.seed }), { seed: run.seed, players, version: 0 });
  for (let step = 0; step < fingerprints.length; step++) {
    if (step > 0) {
      const match = matchOf(result) as Match<AnyGameState, unknown>;
      const move = run.moves[step - 1];
      result = sandbox.run("applyMove", JSON.stringify({ match, move }), { seed: run.seed, players, version: match.version + 1 });
    }
    const failed = failureOf(result);
    if (failed !== undefined) {
      return { severity: "error", kind: "engine", message: `Auf dem Server (QuickJS) scheitert die Partie, hier in Node nicht: ${failed}. ${serverHint}`, ...where, step };
    }
    if (fingerprint(JSON.stringify(matchOf(result))) !== fingerprints[step]) {
      return { severity: "warning", kind: "engine", message: divergence, ...where, step };
    }
  }
  return undefined;
}

function matchOf(result: SandboxResult): unknown {
  return result.ok && result.outcome.ok ? result.outcome.match : undefined;
}

function failureOf(result: SandboxResult): string | undefined {
  if (!result.ok) {
    return result.failure.message;
  }
  return result.outcome.ok ? undefined : result.outcome.error.message;
}
