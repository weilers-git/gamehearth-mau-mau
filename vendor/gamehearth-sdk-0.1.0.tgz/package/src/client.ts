import { bridgeVersion, parsePlatformMessage, type MoveResult, type PlayerInfo } from "./bridge";
import type { PlayerSnapshot } from "./snapshot";
import type { AnyGameState, PerPlayerOf, PlayerId, PublicOf } from "./state";

export type { MoveResult, PlayerInfo } from "./bridge";
export type { GameResult } from "./game";
export type { GameState, PlayerId } from "./state";
export type { PlayerSnapshot } from "./snapshot";

export interface GameUpdate<S extends AnyGameState, A> {
  snapshot: PlayerSnapshot<PublicOf<S>, PerPlayerOf<S>, A>;
  players: Record<PlayerId, PlayerInfo>;
  online: boolean;
}

export interface GameConnection<S extends AnyGameState, A> {
  readonly seat: PlayerId;
  readonly current: GameUpdate<S, A>;
  onUpdate(listener: (update: GameUpdate<S, A>) => void): () => void;
  move(action: A): Promise<MoveResult>;
}

export interface MessageEventLike {
  data: unknown;
  source: unknown;
}

export interface ConnectOptions {
  parent?: { postMessage(message: unknown, targetOrigin: string): void };
  events?: {
    addEventListener(type: "message", listener: (event: MessageEventLike) => void): void;
    removeEventListener(type: "message", listener: (event: MessageEventLike) => void): void;
  };
  connectTimeoutMs?: number;
  moveTimeoutMs?: number;
}

interface Timers {
  setTimeout(callback: () => void, ms: number): unknown;
  clearTimeout(handle: unknown): void;
}

export function connect<S extends AnyGameState, A>(options: ConnectOptions = {}): Promise<GameConnection<S, A>> {
  const global = globalThis as unknown as { parent?: ConnectOptions["parent"] } & ConnectOptions["events"] & Timers;
  const embedder = options.parent ?? global.parent;
  const events = options.events ?? global;
  const timers: Timers = global;
  if (embedder === undefined || events === undefined || embedder === (globalThis as unknown)) {
    return Promise.reject(new Error("Das Spiel läuft nicht in Gamehearth: Es gibt kein Plattform-Fenster, das es eingebettet hat."));
  }
  const parent = embedder;
  const connectTimeoutMs = options.connectTimeoutMs ?? 10_000;
  const moveTimeoutMs = options.moveTimeoutMs ?? 15_000;

  type Connection = { seat: PlayerId; current: GameUpdate<S, A> };

  return new Promise((resolve, reject) => {
    let connection: Connection | undefined;
    const listeners = new Set<(update: GameUpdate<S, A>) => void>();
    const pending = new Map<number, { resolve: (result: MoveResult) => void; timer: unknown }>();
    let nextId = 1;

    const timeout = timers.setTimeout(() => {
      if (connection === undefined) {
        events.removeEventListener("message", receive);
        reject(new Error(`Die Plattform hat sich nicht innerhalb von ${connectTimeoutMs} ms gemeldet.`));
      }
    }, connectTimeoutMs);

    function receive(event: MessageEventLike): void {
      if (event.source !== parent) {
        return;
      }
      const message = parsePlatformMessage(event.data);
      if (message === undefined) {
        return;
      }
      if (message.type === "result") {
        const waiting = pending.get(message.id);
        if (waiting !== undefined) {
          pending.delete(message.id);
          timers.clearTimeout(waiting.timer);
          waiting.resolve(message.ok ? { ok: true } : { ok: false, code: message.code, message: message.message });
        }
        return;
      }
      const update: GameUpdate<S, A> = {
        snapshot: message.snapshot as GameUpdate<S, A>["snapshot"],
        players: message.players,
        online: message.online,
      };
      if (connection === undefined) {
        timers.clearTimeout(timeout);
        connection = { seat: message.seat, current: update };
        resolve(api(connection));
        return;
      }
      connection.current = update;
      for (const listener of [...listeners]) {
        listener(update);
      }
    }

    function api(state: Connection): GameConnection<S, A> {
      return {
        get seat() {
          return state.seat;
        },
        get current() {
          return state.current;
        },
        onUpdate(listener) {
          listeners.add(listener);
          listener(state.current);
          return () => {
            listeners.delete(listener);
          };
        },
        move(action) {
          const id = nextId++;
          const expectedVersion = state.current.snapshot.version;
          return new Promise<MoveResult>((done) => {
            const timer = timers.setTimeout(() => {
              pending.delete(id);
              done({ ok: false, code: "timeout", message: `Die Plattform hat den Zug nicht innerhalb von ${moveTimeoutMs} ms bestätigt.` });
            }, moveTimeoutMs);
            pending.set(id, { resolve: done, timer });
            try {
              parent.postMessage({ gamehearth: bridgeVersion, type: "move", id, action, expectedVersion }, "*");
            } catch (error) {
              pending.delete(id);
              timers.clearTimeout(timer);
              done({ ok: false, code: "illegal-move", message: `Der Zug lässt sich nicht verschicken: ${error instanceof Error ? error.message : String(error)}` });
            }
          });
        },
      };
    }

    events.addEventListener("message", receive);
    parent.postMessage({ gamehearth: bridgeVersion, type: "ready" }, "*");
  });
}
