import Phaser from "phaser";
import type { GameConnection, GameUpdate } from "@gamehearth/sdk/client";
import type { DuelAction, DuelState, Options } from "../../src/index";
import {
  moveFor,
  nameOf,
  opponents,
  playable,
  revealLine,
  rowPositions,
  scoreLine,
  seatState,
  sortedHand,
  statusLine,
  type Snapshot,
} from "./view";

type Update = GameUpdate<DuelState, DuelAction, Options>;

const font = "system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Noto Color Emoji'";
const colors = {
  table: 0x24324a,
  card: 0xfffdf8,
  cardText: "#26303f",
  back: 0x8c3b4a,
  highlight: 0xf2b84b,
  text: "#f3f0ea",
  muted: "#a9b4c6",
};

export class DuelScene extends Phaser.Scene {
  readonly #connection: GameConnection<DuelState, DuelAction, Options>;
  readonly #u: number;
  #update: Update | undefined;
  #busy = false;
  #layer!: Phaser.GameObjects.Container;

  constructor(connection: GameConnection<DuelState, DuelAction, Options>, dpr: number) {
    super("duel");
    this.#connection = connection;
    this.#u = dpr;
  }

  create(): void {
    this.cameras.main.setBackgroundColor(colors.table);
    this.#layer = this.add.container(0, 0);
    this.scale.on("resize", () => this.#render());
    this.#connection.onUpdate((update) => {
      this.#update = update;
      this.#render();
    });
  }

  #render(): void {
    const update = this.#update;
    if (update === undefined) {
      return;
    }
    const snapshot = update.snapshot as Snapshot;
    const players = update.players;
    const u = this.#u;
    const width = this.scale.width;
    const height = this.scale.height;
    const cardWidth = Phaser.Math.Clamp(width / 5, 56 * u, 110 * u);
    const cardHeight = cardWidth * 1.4;
    this.#layer.removeAll(true);

    const others = opponents(snapshot);
    const seatX = rowPositions(others.length, width, width / Math.max(others.length, 1), 0);
    others.forEach((seat, index) => {
      const x = seatX[index] ?? width / 2;
      const y = 24 * u;
      const offline = players[seat]?.connected === false ? " (offline)" : "";
      this.#text(x, y, `${nameOf(seat, players)}${offline}`, 15, colors.text, true);
      this.#text(x, y + 22 * u, [scoreLine(seat, snapshot), seatState(seat, snapshot)].filter((part) => part !== "").join(" · "), 13, colors.muted);
      const revealed = snapshot.public.lastReveal?.cards[seat];
      if (revealed !== undefined) {
        this.#card(x, y + 50 * u + (cardHeight * 0.6) / 2, cardWidth * 0.6, String(revealed), false);
      }
    });

    let y = height * 0.4;
    for (const [value, size, color, bold] of [
      [statusLine(snapshot, players, update.options), 17, colors.text, true],
      [revealLine(snapshot, players), 13, colors.muted, false],
      [`Deine Punkte: ${scoreLine(snapshot.player, snapshot)}`, 14, colors.text, false],
    ] as const) {
      y += this.#text(width / 2, y, value, size, color, bold).height + 10 * u;
    }

    const handY = height - cardHeight / 2 - 18 * u;
    if (snapshot.me.chosen !== null) {
      this.#card(width / 2, handY - cardHeight - 12 * u, cardWidth * 0.8, String(snapshot.me.chosen), false, true);
    }
    const hand = sortedHand(snapshot);
    const legal = playable(snapshot);
    const handX = rowPositions(hand.length, width, cardWidth, 10 * u);
    hand.forEach((card, index) => {
      const canPlay = legal.has(card);
      const shape = this.#card(handX[index] ?? width / 2, canPlay ? handY - 8 * u : handY, cardWidth, String(card), canPlay);
      shape.setAlpha(canPlay || legal.size === 0 ? 1 : 0.6);
      if (canPlay) {
        shape.setInteractive({ useHandCursor: true }).on("pointerup", () => this.#play(card));
      }
    });
  }

  #play(card: number): void {
    const snapshot = this.#update?.snapshot as Snapshot | undefined;
    const move = snapshot === undefined ? undefined : moveFor(snapshot, card);
    if (move === undefined || this.#busy) {
      return;
    }
    this.#busy = true;
    void this.#connection.move(move).finally(() => {
      this.#busy = false;
    });
  }

  #card(x: number, y: number, width: number, label: string, highlight: boolean, faceDown = false): Phaser.GameObjects.Container {
    const u = this.#u;
    const height = width * 1.4;
    const body = this.add.graphics();
    body.fillStyle(faceDown ? colors.back : colors.card, 1);
    body.fillRoundedRect(-width / 2, -height / 2, width, height, 8 * u);
    if (highlight) {
      body.lineStyle(3 * u, colors.highlight, 1);
      body.strokeRoundedRect(-width / 2, -height / 2, width, height, 8 * u);
    }
    const text = this.add
      .text(0, 0, label, { fontFamily: font, fontSize: `${Math.round(width * 0.38)}px`, fontStyle: "700", color: faceDown ? colors.text : colors.cardText })
      .setOrigin(0.5);
    const card = this.add.container(x, y, [body, text]);
    card.setSize(width, height);
    this.#layer.add(card);
    return card;
  }

  #text(x: number, y: number, value: string, size: number, color: string, bold = false): Phaser.GameObjects.Text {
    const u = this.#u;
    const text = this.add
      .text(x, y, value, {
        fontFamily: font,
        fontSize: `${size * u}px`,
        fontStyle: bold ? "700" : "400",
        color,
        align: "center",
        wordWrap: { width: this.scale.width - 32 * u },
      })
      .setOrigin(0.5, 0);
    this.#layer.add(text);
    return text;
  }
}
