export { duel as default, deckSize, duel, fullDeck, handSize } from "./game";
export type { Card, DuelAction, DuelState, Hand, Options, Public, Reveal, Secret } from "./game";
