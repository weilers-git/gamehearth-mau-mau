export interface PlayerCountSpec {
  min: number;
  max?: number;
  counts?: number[];
}

const specKeys = ["min", "max", "counts"];

export function validatePlayerCountSpec(spec: unknown): string[] {
  if (spec === null || typeof spec !== "object" || Array.isArray(spec)) {
    return ['players muss ein Objekt wie { "min": 2, "max": 6 } sein'];
  }
  const errors: string[] = [];
  for (const key of Object.keys(spec)) {
    if (!specKeys.includes(key)) {
      errors.push(`players.${key} ist unbekannt, erlaubt sind min, max und counts`);
    }
  }
  const { min, max, counts } = spec as Record<string, unknown>;
  const validMin = isWholeNumber(min) && min >= 1;
  if (!validMin) {
    errors.push("players.min muss eine ganze Zahl ab 1 sein");
  }
  if (max !== undefined) {
    if (!isWholeNumber(max)) {
      errors.push("players.max muss eine ganze Zahl sein");
    } else if (validMin && max < min) {
      errors.push("players.max darf nicht kleiner als players.min sein");
    }
  }
  if (counts !== undefined) {
    if (!Array.isArray(counts)) {
      errors.push("players.counts muss eine Liste von Spielerzahlen sein");
    } else if (counts.length === 0) {
      errors.push("players.counts darf nicht leer sein, ohne Sonderfall das Feld weglassen");
    } else {
      for (const count of counts) {
        const outside = !isWholeNumber(count) || (validMin && count < min) || (isWholeNumber(max) && count > max);
        if (outside) {
          errors.push(`players.counts enthält ${JSON.stringify(count)}, das liegt nicht zwischen min und max`);
        }
      }
    }
  }
  return errors;
}

export function isPlayerCountAllowed(spec: PlayerCountSpec, count: number, serverMax: number): boolean {
  assertServerMax(serverMax);
  const max = Math.min(spec.max ?? serverMax, serverMax);
  if (!Number.isInteger(count) || count < spec.min || count > max) {
    return false;
  }
  return spec.counts === undefined || spec.counts.includes(count);
}

export function allowedPlayerCounts(spec: PlayerCountSpec, serverMax: number): number[] {
  assertServerMax(serverMax);
  const max = Math.min(spec.max ?? serverMax, serverMax);
  const result: number[] = [];
  for (let count = spec.min; count <= max; count++) {
    if (isPlayerCountAllowed(spec, count, serverMax)) {
      result.push(count);
    }
  }
  return result;
}

function assertServerMax(serverMax: number): void {
  if (!Number.isSafeInteger(serverMax) || serverMax < 1) {
    throw new RangeError(`Die Obergrenze des Servers muss eine ganze Zahl ab 1 sein, bekam ${serverMax}`);
  }
}

function isWholeNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isSafeInteger(value);
}
