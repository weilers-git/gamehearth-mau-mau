import "./prelude";
import { applyMove, createMatch, type AnyGameState, type GameDefinition } from "@gamehearth/sdk/platform";

type AnyGame = GameDefinition<AnyGameState, unknown>;

let installed: AnyGame | undefined;

function game(): AnyGame {
  if (installed === undefined) {
    throw new Error("kein Spiel installiert");
  }
  return installed;
}

const api = {
  install(value: unknown): void {
    const candidate = value as Record<string, unknown> | null;
    const complete =
      candidate !== null &&
      typeof candidate === "object" &&
      ["setup", "legalMoves", "apply", "result"].every((name) => typeof candidate[name] === "function");
    if (!complete) {
      throw new Error(
        "src/index.ts exportiert kein Spiel. Das Spiel muss so exportiert werden: export default defineGame({ setup, legalMoves, apply, result })",
      );
    }
    installed = candidate as unknown as AnyGame;
  },
  createMatch(input: string): string {
    const { playerCount, seed } = JSON.parse(input) as { playerCount: number; seed: string };
    return JSON.stringify(createMatch(game(), { playerCount, seed }));
  },
  applyMove(input: string): string {
    const { match, move } = JSON.parse(input);
    return JSON.stringify(applyMove(game(), match, move));
  },
};

Object.defineProperty(globalThis, "__gamehearth", { value: Object.freeze(api), writable: false, enumerable: false, configurable: false });
