import {
  SeededRandom,
  applyMove,
  createMatch,
  randomStateFromSeed,
  type AnyGameState,
  type GameDefinition,
  type GameResult,
  type Match,
  type MatchError,
  type Move,
} from "@gamehearth/sdk/platform";
import type { Finding } from "./findings";

export type AnyGame = GameDefinition<AnyGameState, unknown>;
export type AnyMatch = Match<AnyGameState, unknown>;

export type Ending = "finished" | "too-long" | "failed";

export interface GameRun {
  playerCount: number;
  seed: string;
  moves: Move<unknown>[];
  ending: Ending;
  result?: GameResult;
  setupFingerprint?: string;
  setupUsedRandom?: boolean;
  fingerprints?: string[];
  findings: Finding[];
}

export interface RunOptions {
  maxMoves: number;
  decoyPlayerCount?: number;
  inspect?: (match: AnyMatch, step: number) => Finding[];
  beforeStep?: (step: number, replaying: boolean) => void;
  onMove?: (move: Move<unknown>) => void;
}

export const clockStart = 1_767_225_600_000;

const snapshotBudget = 20_000_000;

export function playGame(game: AnyGame, playerCount: number, seed: string, options: RunOptions): GameRun {
  const bot = new SeededRandom(randomStateFromSeed(`bot:${seed}`));
  const moves: Move<unknown>[] = [];
  const findings: Finding[] = [];
  const where = { playerCount, seed };

  options.beforeStep?.(0, false);
  const created = createMatch(game, { playerCount, seed });
  if (!created.ok) {
    findings.push(fromMatchError(created.error, { ...where, step: 0 }));
    return { playerCount, seed, moves, ending: "failed", fingerprints: [], findings };
  }
  let match = created.match;
  const history = new History();
  history.add(match);
  const setupFingerprint = fingerprint(JSON.stringify(match.state));
  findings.push(...(options.inspect?.(match, 0) ?? []));

  while (match.result === undefined && moves.length < options.maxMoves) {
    const active = match.players.filter((player) => (match.moves[player] ?? []).length > 0);
    const player = bot.pick(active);
    const move: Move<unknown> = {
      player,
      action: bot.pick(match.moves[player] ?? []),
      now: clockStart + moves.length * 1000,
      expectedVersion: match.version,
    };
    moves.push(move);
    options.onMove?.(move);
    options.beforeStep?.(moves.length, false);
    const before = JSON.stringify(match.state);
    const stored = JSON.parse(JSON.stringify(match)) as AnyMatch;
    const outcome = applyMove(game, stored, JSON.parse(JSON.stringify(move)) as Move<unknown>);
    if (!outcome.ok) {
      findings.push(fromMatchError(outcome.error, { ...where, step: moves.length }));
      return { playerCount, seed, moves, ending: "failed", setupFingerprint, fingerprints: history.fingerprints, findings };
    }
    match = outcome.match;
    if (JSON.stringify(match.state) === before) {
      findings.push({
        severity: "warning",
        kind: "suspicious",
        message:
          "Ein erlaubter Zug ändert den Zustand überhaupt nicht. Meist fehlt in apply die Behandlung dieses Zugs, etwa ein case im switch. Soll der Zug wirklich nichts tun, gehört er nicht in legalMoves.",
        detail: `${player} ${JSON.stringify(move.action)}`,
        ...where,
        step: moves.length,
        player,
      });
    }
    history.add(match);
    findings.push(...(options.inspect?.(match, moves.length) ?? []));
  }

  if (match.result === undefined) {
    findings.push({
      severity: "warning",
      kind: "never-ends",
      message: `Partien enden nach ${options.maxMoves} Zügen mit Zufallsbots noch nicht. Prüfen, ob result das Ende erkennt oder ob sich die Partie im Kreis drehen kann.`,
      ...where,
      step: moves.length,
    });
  }

  const divergence = replayDivergence(game, playerCount, seed, moves, history, options);
  if (divergence !== undefined) {
    const finding: Finding = {
      severity: "error",
      kind: "nondeterministic",
      message:
        "Dieselbe Partie ergibt beim Wiederholen einen anderen Zustand. Das Spiel hängt von etwas anderem ab als von Zustand, Zug und ctx: etwa von Variablen außerhalb der Funktionen, die sich setup merkt oder die sich zwischen Partien ändern. Auf dem Server laufen viele Partien gleichzeitig im selben Modul.",
      ...where,
      step: divergence.step,
    };
    if (divergence.detail !== undefined) {
      finding.detail = divergence.detail;
    }
    findings.push(finding);
  }

  const base = { playerCount, seed, moves, setupFingerprint, fingerprints: history.fingerprints, findings };
  return match.result === undefined
    ? { ...base, ending: "too-long" }
    : { ...base, ending: "finished", result: match.result };
}

class History {
  readonly #fingerprints: string[] = [];
  readonly #snapshots: (string | undefined)[] = [];
  #size = 0;

  get fingerprints(): string[] {
    return [...this.#fingerprints];
  }

  add(match: AnyMatch): void {
    const text = JSON.stringify(match);
    this.#fingerprints.push(fingerprint(text));
    if (this.#size + text.length <= snapshotBudget) {
      this.#snapshots.push(text);
      this.#size += text.length;
    } else {
      this.#snapshots.push(undefined);
    }
  }

  matches(step: number, match: AnyMatch): boolean {
    return this.#fingerprints[step] === fingerprint(JSON.stringify(match));
  }

  describe(step: number, actual: AnyMatch | undefined): string | undefined {
    const expected = this.#snapshots[step];
    if (expected === undefined || actual === undefined) {
      return undefined;
    }
    return firstDifference(JSON.parse(expected), JSON.parse(JSON.stringify(actual)), "match");
  }
}

interface Divergence {
  step: number;
  detail?: string;
}

function replayDivergence(
  game: AnyGame,
  playerCount: number,
  seed: string,
  moves: readonly Move<unknown>[],
  history: History,
  options: RunOptions,
): Divergence | undefined {
  const decoy = new Decoy(game, options.decoyPlayerCount ?? playerCount, seed);
  const diverged = (step: number, actual: AnyMatch | undefined): Divergence => {
    const detail = history.describe(step, actual);
    return detail === undefined ? { step } : { step, detail };
  };
  options.beforeStep?.(0, true);
  const created = createMatch(game, { playerCount, seed });
  if (!created.ok) {
    return { step: 0, detail: `beim Wiederholen meldet setup: ${created.error.message}` };
  }
  let match = created.match;
  if (!history.matches(0, match)) {
    return diverged(0, match);
  }
  decoy.advance();
  for (let step = 1; step <= moves.length; step++) {
    decoy.advance();
    options.beforeStep?.(step, true);
    const outcome = applyMove(game, match, moves[step - 1] as Move<unknown>);
    if (!outcome.ok) {
      return { step, detail: `beim Wiederholen wird der Zug abgelehnt: ${outcome.error.message}` };
    }
    if (!history.matches(step, outcome.match)) {
      return diverged(step, outcome.match);
    }
    match = outcome.match;
  }
  return undefined;
}

class Decoy {
  readonly #game: AnyGame;
  readonly #playerCount: number;
  readonly #seed: string;
  readonly #bot: SeededRandom;
  #match: AnyMatch | undefined;
  #round = 0;

  constructor(game: AnyGame, playerCount: number, seed: string) {
    this.#game = game;
    this.#playerCount = playerCount;
    this.#seed = seed;
    this.#bot = new SeededRandom(randomStateFromSeed(`decoy:${seed}`));
  }

  advance(): void {
    try {
      if (this.#match === undefined || this.#match.result !== undefined) {
        this.#round += 1;
        const created = createMatch(this.#game, { playerCount: this.#playerCount, seed: `decoy:${this.#seed}:${this.#round}` });
        this.#match = created.ok ? created.match : undefined;
        return;
      }
      const match = this.#match;
      const active = match.players.filter((player) => (match.moves[player] ?? []).length > 0);
      const player = this.#bot.pick(active);
      const outcome = applyMove(this.#game, match, {
        player,
        action: this.#bot.pick(match.moves[player] ?? []),
        now: clockStart,
      });
      this.#match = outcome.ok ? outcome.match : undefined;
    } catch {
      this.#match = undefined;
    }
  }
}

export function firstDifference(expected: unknown, actual: unknown, path: string): string | undefined {
  if (JSON.stringify(expected) === JSON.stringify(actual)) {
    return undefined;
  }
  const isObject = (value: unknown) => value !== null && typeof value === "object";
  if (isObject(expected) && isObject(actual) && Array.isArray(expected) === Array.isArray(actual)) {
    const a = expected as Record<string, unknown>;
    const b = actual as Record<string, unknown>;
    const keys = [...new Set([...Object.keys(a), ...Object.keys(b)])];
    for (const key of keys) {
      const childPath = Array.isArray(expected) ? `${path}[${key}]` : `${path}.${key}`;
      const difference = firstDifference(a[key], b[key], childPath);
      if (difference !== undefined) {
        return difference;
      }
    }
  }
  return `${path}: beim ersten Durchlauf ${short(expected)}, beim Wiederholen ${short(actual)}`;
}

function short(value: unknown): string {
  const text = value === undefined ? "nicht vorhanden" : JSON.stringify(value);
  return text.length > 120 ? `${text.slice(0, 117)}...` : text;
}

export function fromMatchError(error: MatchError, where: { playerCount: number; seed: string; step: number }): Finding {
  const finding: Finding = {
    severity: "error",
    kind: "game-error",
    message: error.code === "game-error" ? error.message : `Unerwartete Ablehnung (${error.code}): ${error.message}`,
    ...where,
  };
  if (error.phase !== undefined) {
    finding.phase = error.phase;
  }
  if (error.player !== undefined) {
    finding.player = error.player;
  }
  if (error.stack !== undefined) {
    finding.stack = gameFrames(error.stack);
  }
  return finding;
}

const platformFrame = /[\\/](sdk|devtool)[\\/]src[\\/]|[\\/]@gamehearth[\\/](sdk|devtool)[\\/]|gamehearth-check-/;

export function gameFrames(stack: string): string {
  const lines = stack.split("\n");
  const kept = lines.filter((line, index) => index === 0 || !line.trim().startsWith("at ") || !platformFrame.test(line));
  return kept.length > 1 ? kept.join("\n") : stack;
}

export function fingerprint(text: string): string {
  let hash = 0x811c9dc5;
  for (let i = 0; i < text.length; i++) {
    hash ^= text.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return `${text.length}:${(hash >>> 0).toString(16)}`;
}
