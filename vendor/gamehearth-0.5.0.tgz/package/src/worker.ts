import type { GameOptions, Move, Random } from "@gamehearth/sdk/platform";
import { parentPort, workerData } from "node:worker_threads";
import type { Finding } from "./findings";
import { heartbeatSlots, phaseCodes, takeForbiddenCall, type HeartbeatPhase } from "./heartbeat";
import { findLeaks } from "./leaks";
import { playGame, type AnyGame, type GameRun } from "./runner";

export interface Job {
  playerCount: number;
  seed: string;
  options?: GameOptions;
  decoyPlayerCount?: number;
}

export interface WorkerInput {
  jobs: Job[];
  startIndex: number;
  maxMoves: number;
  maxTicks?: number;
  realtime?: boolean;
  heartbeat: Int32Array;
  streamMoves?: boolean;
  maxTooLong?: number;
}

export type WorkerMessage =
  | { type: "run"; index: number; run: GameRun }
  | { type: "move"; index: number; move: Move<unknown> }
  | { type: "invalid" }
  | { type: "done"; skipped: boolean };

export function startWorker(candidate: unknown): void {
  const input = workerData as WorkerInput;
  const port = parentPort;
  if (port === null) {
    throw new Error("startWorker läuft nur in einem Worker-Thread");
  }
  if (!isGame(candidate)) {
    port.postMessage({ type: "invalid" } satisfies WorkerMessage);
    return;
  }
  const { heartbeat } = input;
  let tooLong = 0;
  for (let index = input.startIndex; index < input.jobs.length; index++) {
    const job = input.jobs[index] as Job;
    Atomics.store(heartbeat, heartbeatSlots.job, index);
    takeForbiddenCall(heartbeat);
    const players = Array.from({ length: job.playerCount }, (_, seat) => `p${seat + 1}`);
    const usage = { setupUsedRandom: false };
    const game = instrument(candidate, heartbeat, players, usage);
    const where = { playerCount: job.playerCount, seed: job.seed, ...(job.options === undefined || Object.keys(job.options).length === 0 ? {} : { options: job.options }) };
    const options = {
      ...(job.options === undefined ? {} : { gameOptions: job.options }),
      maxMoves: input.maxMoves,
      ...(input.maxTicks === undefined ? {} : { maxTicks: input.maxTicks }),
      ...(input.realtime === undefined ? {} : { realtime: input.realtime }),
      inspect: (match: Parameters<typeof findLeaks>[1], step: number) => [
        ...forbiddenFindings(heartbeat, { ...where, step }),
        ...findLeaks(game, match, { ...where, step }),
      ],
      beforeStep: (step: number, replaying: boolean) => {
        Atomics.store(heartbeat, heartbeatSlots.step, step);
        Atomics.store(heartbeat, heartbeatSlots.replaying, replaying ? 1 : 0);
        Atomics.add(heartbeat, heartbeatSlots.beats, 1);
      },
      ...(input.streamMoves === true
        ? { onMove: (move: Move<unknown>) => port.postMessage({ type: "move", index, move } satisfies WorkerMessage) }
        : {}),
      ...(job.decoyPlayerCount === undefined ? {} : { decoyPlayerCount: job.decoyPlayerCount }),
    };
    const run = playGame(game, job.playerCount, job.seed, options);
    run.setupUsedRandom = usage.setupUsedRandom;
    port.postMessage({ type: "run", index, run } satisfies WorkerMessage);
    if (run.ending === "too-long") {
      tooLong += 1;
      if (input.maxTooLong !== undefined && tooLong >= input.maxTooLong && index + 1 < input.jobs.length) {
        port.postMessage({ type: "done", skipped: true } satisfies WorkerMessage);
        return;
      }
    }
  }
  port.postMessage({ type: "done", skipped: false } satisfies WorkerMessage);
}

function forbiddenFindings(heartbeat: Int32Array, where: { playerCount: number; seed: string; options?: GameOptions; step: number }): Finding[] {
  const call = takeForbiddenCall(heartbeat);
  if (call === undefined) {
    return [];
  }
  return [
    {
      severity: "error",
      kind: "forbidden",
      message: `${call} wurde im Spiel aufgerufen, der Fehler aber abgefangen (try/catch). Auch auf dem Server ist der Aufruf gesperrt; das Spiel rechnet also mit einem Wert, den es nie bekommt. Zufall kommt aus ctx.random, die Zeit aus ctx.now, Datumswerte über die UTC-Methoden.`,
      ...where,
    },
  ];
}

function instrument(game: AnyGame, heartbeat: Int32Array, players: readonly string[], usage: { setupUsedRandom: boolean }): AnyGame {
  const enter = (phase: HeartbeatPhase, player?: string) => {
    Atomics.store(heartbeat, heartbeatSlots.phase, phaseCodes.indexOf(phase) + 1);
    Atomics.store(heartbeat, heartbeatSlots.seat, player === undefined ? -1 : players.indexOf(player));
    Atomics.add(heartbeat, heartbeatSlots.beats, 1);
  };
  return {
    setup: (ctx) => {
      enter("setup");
      return game.setup({ ...ctx, random: watched(ctx.random, usage) });
    },
    legalMoves: (state, player, ctx) => {
      enter("legalMoves", player);
      return game.legalMoves(state, player, ctx);
    },
    apply: (state, action, ctx) => {
      enter("apply", ctx.player);
      return game.apply(state, action, ctx);
    },
    result: (state) => {
      enter("result");
      return game.result(state);
    },
    ...(typeof game.tick === "function"
      ? {
          tick: (state: Parameters<NonNullable<AnyGame["tick"]>>[0], dt: number, ctx: Parameters<NonNullable<AnyGame["tick"]>>[2]) => {
            enter("tick");
            return game.tick?.(state, dt, ctx);
          },
        }
      : {}),
  };
}

function watched(random: Random, usage: { setupUsedRandom: boolean }): Random {
  return {
    next: () => {
      usage.setupUsedRandom = true;
      return random.next();
    },
    int: (min, max) => {
      usage.setupUsedRandom = true;
      return random.int(min, max);
    },
    pick: (items) => {
      usage.setupUsedRandom = true;
      return random.pick(items);
    },
    shuffle: (items) => {
      usage.setupUsedRandom = true;
      return random.shuffle(items);
    },
    weighted: (entries) => {
      usage.setupUsedRandom = true;
      return random.weighted(entries);
    },
  };
}

function isGame(value: unknown): value is AnyGame {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const game = value as Record<string, unknown>;
  return ["setup", "legalMoves", "apply", "result"].every((name) => typeof game[name] === "function");
}
