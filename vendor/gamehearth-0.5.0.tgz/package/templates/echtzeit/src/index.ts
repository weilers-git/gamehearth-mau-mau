export {
  catcherSpeed,
  clamp,
  directions,
  fieldHeight,
  fieldWidth,
  freezeTicks,
  radius,
  runnerSpeed,
  startPoint,
  tag as default,
  tag,
  tagBackTicks,
  ticksPerSecond,
  touching,
} from "./game";
export type { Direction, Options, Point, Public, TagAction, TagState } from "./game";
